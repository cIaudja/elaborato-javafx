module com.example.casasalute {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.apache.pdfbox;
    requires java.desktop;


    opens com.example.casasalute to javafx.fxml;
    exports com.example.casasalute;
}