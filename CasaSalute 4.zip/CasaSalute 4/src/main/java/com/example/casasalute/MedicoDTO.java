package com.example.casasalute;

public class MedicoDTO {
    private String codiceFiscale;
    private String nome;
    private String cognome;
    private String email;
    private String password;
    private String specialita;
    private String sostituto1;
    private String sostituto2;

    // Costruttore
    public MedicoDTO(String codiceFiscale, String nome, String cognome, String email, String password, String specialita, String sostituto1, String sostituto2) {
        this.codiceFiscale = codiceFiscale;
        this.nome = nome;
        this.cognome = cognome;
        this.email = email;
        this.password = password;
        this.specialita = specialita;
        this.sostituto1 = sostituto1;
        this.sostituto2 = sostituto2;
    }

    // Getter e Setter
    public String getCodiceFiscale() {
        return codiceFiscale;
    }
    public void setCodiceFiscale(String codiceFiscale) {
        this.codiceFiscale = codiceFiscale;
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }
    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public String getSpecialita() {
        return specialita;
    }
    public void setSpecialita(String specialita) {
        this.specialita = specialita;
    }

    public String getSostituto1() {
        return sostituto1;
    }
    public void setSostituto1(String sostituto1) {
        this.sostituto1 = sostituto1;
    }

    public String getSostituto2() {
        return sostituto2;
    }
    public void setSostituto2(String sostituto2) {
        this.sostituto2 = sostituto2;
    }

    @Override
    public String toString() {
        return this.codiceFiscale + "\t" +
                this.nome + "\t" +
                this.cognome + "\t" +
                this.email + "\t" +
                this.password + "\t" +
                this.specialita + "\t" +
                this.sostituto1 + "\t" +
                this.sostituto2;
    }
}