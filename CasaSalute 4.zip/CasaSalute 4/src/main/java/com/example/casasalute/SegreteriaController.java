package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class SegreteriaController implements Initializable {

    @FXML private ListView<MailDTO> mail;
    private final List<MailDTO> mails = ModelMail.getInstance().getAllMail();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<MailDTO> emails = FXCollections.observableArrayList(mails);

        mail.setItems(emails);
        mail.setCellFactory(new Callback<>() {
            @Override
            public ListCell<MailDTO> call(ListView<MailDTO> listView) {
                return new ListCell<>() {
                    @Override
                    protected void updateItem(MailDTO email, boolean empty) {
                        super.updateItem(email, empty);
                        if (empty || email == null) {
                            setText(null);
                            setGraphic(null);
                        } else {
                            VBox emailBox = new VBox();
                            emailBox.setStyle("-fx-padding: 15; -fx-border-color: #007B7F; -fx-border-radius: 5; -fx-background-color: #E0F2F1;");
                            Label labelOggetto = new Label(email.getOggetto() + " disponibile");
                            labelOggetto.setStyle("-fx-font-family: SansSerif; -fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: black;");
                            Label labelMittente = new Label("Mittente: " + email.getMittente());
                            labelMittente.setStyle("-fx-text-fill: #555;");
                            Label labelDestinatario = getLabelDestinatario(email);
                            emailBox.getChildren().addAll(labelOggetto, labelMittente, labelDestinatario);

                            setGraphic(emailBox);
                            setOnMouseClicked(event -> {
                                if (!isEmpty()) {
                                    email.mostraDettagliEmail(email);
                                }
                            });
                        }
                    }
                };
            }
        });
    }
        private static Label getLabelDestinatario(MailDTO email) {
        Label labelDestinatario;
        if (email.getDestinatario().equals("null") && !email.getEmailTutore().equals("null")) {
            labelDestinatario = new Label("Destinatario: " + email.getEmailTutore());
        } else if (!email.getDestinatario().equals("null") && !email.getEmailTutore().equals("null")) {
            labelDestinatario = new Label("Destinatario: " + email.getDestinatario() + "\nTutore: " + email.getEmailTutore());
        } else {
            labelDestinatario = new Label("Destinatario: " + email.getDestinatario());
        }

        labelDestinatario.setStyle("-fx-text-fill: #555;");
        return labelDestinatario;
    }

    @FXML
    public void visualizzaDatiPaziente() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("VisualizzaDatiPaziente.fxml");
    }
    @FXML
    public void visualizzaDatiInfermiere() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("VisualizzaDatiInfermiere.fxml");
    }
    @FXML
    public void visualizzaDatiMedico() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("VisualizzaDatiMedico.fxml");
    }
    @FXML
    public void resocontoPaziente() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("VisualizzaDatiPazienteResoconto.fxml", "s");
    }
    @FXML
    public void storicoVisiteSegreteria() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("storicoRefertiSegreteria.fxml");
    }

    @FXML
    public void logOut() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("Login.fxml");
    }
}
