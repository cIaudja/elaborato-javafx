package com.example.casasalute;

public class TurnoDTO {
    private final String codiceFiscaleInfermiere;
    private final String giorno;
    private final String turno; // "Sala Prelievi" o "Sala Medicazione"

    public TurnoDTO(String codiceFiscaleInfermiere, String giorno, String turno) {
        this.codiceFiscaleInfermiere = codiceFiscaleInfermiere;
        this.giorno = giorno;
        this.turno = turno;
    }

    public String getCodiceFiscaleInfermiere() { return codiceFiscaleInfermiere; }
    public String getGiorno() { return giorno; }

    public String getTurno() { return turno; }

    @Override
    public String toString() {
        return codiceFiscaleInfermiere + "\t" +
                giorno + "\t" +
                turno;
    }
}
