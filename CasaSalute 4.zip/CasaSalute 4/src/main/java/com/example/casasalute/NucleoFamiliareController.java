package com.example.casasalute;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import java.io.IOException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class NucleoFamiliareController implements DataReceiver {

    @FXML private Label nomePaziente;
    @FXML private VBox figliVBox;
    @FXML private Label errore;
    @FXML private TextField nomeF;
    @FXML private TextField cognomeF;
    @FXML private TextField dataF;
    @FXML private TextField luogoF;
    private final List<PazienteDTO> pazienti = ModelPazienti.getInstance().getAllPazienti();
    private PazienteDTO paziente;
    private final List<PazienteDTO> figli = new ArrayList<>();

    @Override
    public void setData(Object data) {
        if (data instanceof PazienteDTO) {
            setNomePaziente((PazienteDTO) data);
            paziente = (PazienteDTO) data;
            creaVbox();
        }
    }

    private void setNomePaziente(PazienteDTO paziente) {
        nomePaziente.setText(paziente.getNome() + " " + paziente.getCognome());
    }

    private void creaVbox() {
        figliVBox.getChildren().clear();
        figli.clear();

        for (PazienteDTO x : pazienti) {
            if (x.getCSTutore().equals(paziente.getCodiceSanitario())) {
                figli.add(x);
            }
        }

        for (PazienteDTO x : figli) {
            Label labelNomeF = new Label(x.getNome() + " " + x.getCognome());
            labelNomeF.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");

            Label labelAnnof = new Label(" Data di nascita: " + x.getData());
            labelAnnof.setStyle("-fx-text-fill: #555;");

            Label labelLuogof = new Label(" Luogo di nascita: " + x.getLuogo());
            labelLuogof.setStyle("-fx-text-fill: #555;");

            VBox vBox = new VBox(labelNomeF, labelAnnof, labelLuogof);
            vBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
            vBox.setSpacing(5);

            vBox.prefWidthProperty().bind(figliVBox.widthProperty());
            figliVBox.getChildren().add(vBox);

            vBox.setOnMouseClicked(event -> {
                try {
                    profiloFiglio(x);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        }
    }

    public void profiloFiglio(PazienteDTO figlio) throws IOException {
        List<Object> dati = new ArrayList<>();
        dati.add(paziente);
        dati.add(figlio);
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("ProfiloFiglio.fxml", dati);
    }

    @FXML
    public void salvaF(){
        String dataInserita = dataF.getText().trim();
        errore.setText("");

        if (nomeF.getText().isEmpty() || cognomeF.getText().isEmpty() || dataF.getText().isEmpty() || luogoF.getText().isEmpty() ) {
            errore.setText("Tutti i campi devono essere compilati");
        }else if (!dataInserita.matches("\\d{2}/\\d{2}/\\d{4}")) {
            errore.setText("Formato data non valido. Usa gg/mm/aaaa");
        }else if (calcolaEta(dataInserita) >= 14) {
            errore.setText("Il figlio deve avere meno di 14 anni");
        } else if(calcolaEta(dataInserita) < 0){
            errore.setText(("Errore"));
        }
        else {
            PazienteDTO nuovoFiglio = new PazienteDTO(nomeF.getText(), cognomeF.getText(), dataF.getText(), luogoF.getText(), "null", "null", paziente.getEmail(), paziente.getMedico(), paziente.getCodiceSanitario());
            for (PazienteDTO x : pazienti)
                if (x.getCodiceSanitario().equals(nuovoFiglio.getCodiceSanitario()))
                {
                    errore.setText("Questo paziente esiste già!");
                    return;
                }
            ModelPazienti.aggiungiPaziente(nuovoFiglio);

            creaVbox();
            nomeF.clear();
            cognomeF.clear();
            dataF.clear();
            luogoF.clear();
        }
    }

    private int calcolaEta(String dataNascita) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        try {
            LocalDate dataNascitaParsed = LocalDate.parse(dataNascita, formatter);
            if (dataNascitaParsed.isAfter(LocalDate.now())) {
                errore.setText("La data di nascita non può essere nel futuro.");
                return -1;
            }
            return Period.between(dataNascitaParsed, LocalDate.now()).getYears();
        } catch (DateTimeParseException e) {
            errore.setText("Data di nascita non valida.");
            return -1;
        }
    }


    @FXML
    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("ProfiloUser.fxml", paziente);
    }
}
