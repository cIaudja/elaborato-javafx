package com.example.casasalute;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.io.IOException;
import java.util.List;
import java.util.Random;

public class CreaInfermiereController {

    @FXML private Label errore;
    @FXML private TextField codiceFiscaleText;
    @FXML private TextField nomeText;
    @FXML private TextField cognomeText;
    @FXML private TextField emailText;
    @FXML private PasswordField passwordText;
    private final List<InfermiereDTO> infermieri = ModelInfermieri.getInstance().getAllInfermieri();

    @FXML
    private void creaInfermiere() throws IOException {
        HelloApplication pagina = new HelloApplication();
        if (controlli()) {
            InfermiereDTO nuovoInfermiere = new InfermiereDTO(codiceFiscaleText.getText(), nomeText.getText(), cognomeText.getText(), emailText.getText(), passwordText.getText());
            for (InfermiereDTO x : infermieri)
                if (x.getCodiceFiscale().equals(nuovoInfermiere.getCodiceFiscale())){
                    errore.setText("Questo infermiere esiste già!");
                    return;
                }
            ModelInfermieri.getInstance().aggiungiInfermiere(nuovoInfermiere);
            assegnaTurniAutomatici(nuovoInfermiere);
            pagina.changeScene("VisualizzaDatiInfermiere.fxml");
        }
    }
    private boolean controlli() {
        if (nomeText.getText().isEmpty() || cognomeText.getText().isEmpty() || emailText.getText().isEmpty() || passwordText.getText().isEmpty()) {
            errore.setText("Tutti i campi devono essere compilati!");
            return false;
        }
        if (!emailText.getText().matches("^[\\w.-]+@[a-zA-Z\\d.-]+\\.[a-zA-Z]{2,}$")) {
            errore.setText("L'email non è valida. Assicurati che sia nel formato corretto.");
            return false;
        }
        return validaCodiceFiscale();
    }

    public boolean validaCodiceFiscale() {
        String cf = codiceFiscaleText.getText().toUpperCase(); // Converti in maiuscolo per sicurezza
        if (!cf.matches("^[A-Z]{6}\\d{2}[A-EHLMPRST]\\d{2}[A-Z]\\d{3}[A-Z]$")) {
            errore.setText("Il codice fiscale non è valido. Controlla che sia nel formato corretto.");
            return false;
        }
        char mese = cf.charAt(8);
        if ("ABCDEHLMPRST".indexOf(mese) == -1) {
            errore.setText("Il mese di nascita nel codice fiscale non è valido.");
            return false;
        }
        return true;
    }

    private void assegnaTurniAutomatici(InfermiereDTO infermiere) {
        int n = infermieri.size();
        String[] giorni = {"Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì"};
        String[] turniPari = {"Sala Prelievi", "Sala Medicazione", "Sala Prelievi", "Sala Medicazione", "Sala Prelievi"};
        String[] turniDispari = {"Sala Medicazione", "Sala Prelievi", "Sala Medicazione", "Sala Prelievi", "Sala Medicazione"};
        Random random = new Random();
        int giornoLiberoIndex = random.nextInt(5);
        for (int i = 0; i < 5; i++) {
            if (i == giornoLiberoIndex) {
                TurnoDTO giornoLibero = new TurnoDTO(infermiere.getCodiceFiscale(), giorni[i], "-");
                ModelTurni.getInstance().aggiungiTurno(giornoLibero);
                continue;
            }
            TurnoDTO nuovoTurno;
            if (n % 2 == 0) {
                nuovoTurno = new TurnoDTO(infermiere.getCodiceFiscale(), giorni[i], turniPari[i]);
            } else {
                nuovoTurno = new TurnoDTO(infermiere.getCodiceFiscale(), giorni[i], turniDispari[i]);
            }
            ModelTurni.getInstance().aggiungiTurno(nuovoTurno);
        }
    }

    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("VisualizzaDatiInfermiere.fxml");
    }
}
