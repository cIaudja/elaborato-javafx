package com.example.casasalute;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.io.IOException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RefertiPrenotazioniController implements DataReceiver {

    @FXML private Label titolo;
    @FXML private Label nome;
    @FXML private Label titolo2;
    @FXML private VBox prenotazioniBox;
    private final List<String[]> visite = ModelPrenotazioni.getInstance().getAllVisite();
    private final List<String[]> prenotazioni = ModelPrenotazioni.getInstance().getAllPrestazioni();
    private final List<PazienteDTO> pazienti = ModelPazienti.getInstance().getAllPazienti();
    private MedicoDTO medico;
    private InfermiereDTO infermiere;

    @Override
    public void setData(Object data) {
        if (data instanceof MedicoDTO) {
            medico = (MedicoDTO) data;
            setNomeMedico();
            creaVboxMedico();
        } else if (data instanceof InfermiereDTO) {
            infermiere = (InfermiereDTO) data;
            setNomeInfermiere();
            creaVboxInfermiere();
        }
    }

    public void setNomeMedico(){
        titolo.setText("MEDICO");
        nome.setText(medico.getNome() + " " + medico.getCognome());
        titolo2.setText("Inserisci esito visita da prenotazione");
    }

    public void setNomeInfermiere(){
        titolo.setText("INFERMIERE");
        nome.setText(infermiere.getNome() + " " + infermiere.getCognome());
        titolo2.setText("Inserisci esito prestazione da prenotazione");
    }

    public void creaVboxMedico() {
        prenotazioniBox.getChildren().clear(); // Pulisce gli elementi esistenti nella VBox
        List<String[]> prenotazioniFiltrate = new ArrayList<>();// Filtro delle prenotazioni per il medico selezionato
        for (String[] x : visite) {
            if (x[0].equals(medico.getCodiceFiscale())) {
                prenotazioniFiltrate.add(x);
            }
        }
        // Ordinamento delle prenotazioni per data e ora
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        prenotazioniFiltrate.sort((a, b) -> {
            LocalDate dataA = LocalDate.parse(a[3], dateFormatter);
            LocalDate dataB = LocalDate.parse(b[3], dateFormatter);
            if (!dataA.equals(dataB)) {
                return dataA.compareTo(dataB); // Ordine crescente per data
            } else {
                LocalTime oraA = LocalTime.parse(a[4], timeFormatter);
                LocalTime oraB = LocalTime.parse(b[4], timeFormatter);
                return oraB.compareTo(oraA); // Ordine decrescente per ora
            }
        });
        for (String[] x : prenotazioniFiltrate) {// Creazione delle VBox per ogni prenotazione
            PazienteDTO paziente = null;
            for (PazienteDTO y : pazienti) {
                if (y.getCodiceSanitario().equals(x[1])) {
                    paziente = y;
                    break;
                }
            }
            if (paziente != null) {
                HBox prenBox = getPrenBox(x, paziente);
                prenBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
                prenBox.setSpacing(20);
                prenBox.prefWidthProperty().bind(prenotazioniBox.widthProperty());
                prenotazioniBox.getChildren().add(prenBox);
                prenBox.setOnMouseClicked(event -> {
                    try {
                        creaReferto(x);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
            }
        }
    }

    private static HBox getPrenBox(String[] x, PazienteDTO paziente) {
        Label labelNomePaziente = new Label(paziente.getNome() + " " + paziente.getCognome());
        labelNomePaziente.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");
        Label labelTipoPrenotazione = new Label(x[2].equals("Adulti") ? "Visita medica" : "Visita pediatrica");
        labelTipoPrenotazione.setStyle("-fx-text-fill: #555;");
        Label labelDataPrenotazione = new Label(" Data: " + x[3]);
        labelDataPrenotazione.setStyle("-fx-text-fill: #555;");
        Label labelOraPrenotazione = new Label(" Ora: " + x[4]);
        labelOraPrenotazione.setStyle("-fx-text-fill: #555;");
        Label labelRegimePrenotazione = new Label(" Regime: " + x[5]);
        labelRegimePrenotazione.setStyle("-fx-text-fill: #555;");
        return new HBox(labelNomePaziente, labelTipoPrenotazione, labelDataPrenotazione, labelOraPrenotazione, labelRegimePrenotazione);
    }

    public void creaVboxInfermiere() {
        prenotazioniBox.getChildren().clear(); // Pulisce gli elementi esistenti nella VBox
        List<String[]> prenotazioniFiltrate = new ArrayList<>();
        List<TurnoDTO> turniInfermiere = ModelTurni.getInstance().getTurniInfermiere(infermiere.getCodiceFiscale());
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        DateTimeFormatter formatterGiorno = DateTimeFormatter.ofPattern("EEEE", Locale.ITALIAN); // Formatter per il giorno in italiano
        for (String[] x : prenotazioni) {
            if (x[0].equals("Prelievo") || x[0].equals("Medicazione")) {
                LocalDate dataPrenotazione = LocalDate.parse(x[2], dateFormatter);
                String giornoSettimanaString = dataPrenotazione.format(formatterGiorno); // Giorno della settimana in italiano
                for (TurnoDTO y : turniInfermiere) {
                    if (giornoSettimanaString.equalsIgnoreCase(y.getGiorno()) && (((x[0].equals("Prelievo") && y.getTurno().contains("Prelievi")) || (x[0].equals("Medicazione") && y.getTurno().contains("Medicazione"))))) {
                        prenotazioniFiltrate.add(x);
                    }
                }
            }
        }
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm"); // Ordinamento per data e ora
        prenotazioniFiltrate.sort((a, b) -> {
            LocalDate dataA = LocalDate.parse(a[2], dateFormatter);
            LocalDate dataB = LocalDate.parse(b[2], dateFormatter);
            if (!dataA.equals(dataB)) {
                return dataA.compareTo(dataB); // Ordine crescente per data
            } else {
                LocalTime oraA = LocalTime.parse(a[3], timeFormatter);
                LocalTime oraB = LocalTime.parse(b[3], timeFormatter);
                return oraB.compareTo(oraA); // Ordine decrescente per ora
            }
        });
        for (String[] x : prenotazioniFiltrate) { // Creazione delle VBox per ogni prenotazione
            PazienteDTO paziente = null;
            for (PazienteDTO y : pazienti) {
                if (y.getCodiceSanitario().equals(x[1])) {
                    paziente = y;
                    break;
                }
            }
            if (paziente != null) {
                HBox prenBox = getBox(x, paziente);
                prenBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
                prenBox.setSpacing(20);
                prenBox.prefWidthProperty().bind(prenotazioniBox.widthProperty());
                prenotazioniBox.getChildren().add(prenBox);
                prenBox.setOnMouseClicked(event -> {
                    try {
                        creaReferto(x);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
            }
        }
    }

    private static HBox getBox(String[] x, PazienteDTO paziente) {
        Label labelNomePaziente = new Label(paziente.getNome() + " " + paziente.getCognome());
        labelNomePaziente.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");
        Label labelTipoPrenotazione = new Label(x[0]); // Direttamente dal tipo di prenotazione
        labelTipoPrenotazione.setStyle("-fx-text-fill: #555;");
        Label labelDataPrenotazione = new Label(" Data: " + x[2]);
        labelDataPrenotazione.setStyle("-fx-text-fill: #555;");
        Label labelOraPrenotazione = new Label(" Ora: " + x[3]);
        labelOraPrenotazione.setStyle("-fx-text-fill: #555;");
        return new HBox(labelNomePaziente, labelTipoPrenotazione, labelDataPrenotazione, labelOraPrenotazione);
    }

    private void creaReferto(String[] datiPrenotazione) throws IOException {
        List<Object> dati = new ArrayList<>();
        HelloApplication pagina = new HelloApplication();
        if (medico != null){
            dati.add(medico);
            dati.add(datiPrenotazione[1]); //CS paziente
            dati.add(datiPrenotazione[2]); //tipo di visita
            dati.add(datiPrenotazione[3]); //data visita
            dati.add(datiPrenotazione[4]); //ora visita
            dati.add(datiPrenotazione[5]); //regime
            dati.add(datiPrenotazione[6]); //ambulatorio
            pagina.changeSceneWithData("CreaVisita.fxml", dati);
        } else if (infermiere != null){
            dati.add(infermiere);
            dati.add(datiPrenotazione[0]); //tipo di prestazione
            dati.add(datiPrenotazione[1]); //CS paziente
            dati.add(datiPrenotazione[2]); //data prestazione
            dati.add(datiPrenotazione[3]); //ora prestazione
            pagina.changeSceneWithData("CreaPrestazione.fxml", dati);
        }
    }

    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        if (infermiere != null)
            pagina.changeSceneWithData("StoricoReferti.fxml", infermiere);
        if (medico != null)
            pagina.changeSceneWithData("StoricoReferti.fxml", medico);
    }
}