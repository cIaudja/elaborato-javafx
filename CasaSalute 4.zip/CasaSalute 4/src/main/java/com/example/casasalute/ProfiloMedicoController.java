package com.example.casasalute;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;


public class ProfiloMedicoController implements DataReceiver {

    @FXML private Label nomeMedico;
    @FXML private VBox mediciSostituiti;
    @FXML private VBox visiteOggi;
    private MedicoDTO medico;
    private final List <MedicoDTO> medici = ModelMedici.getInstance().getAllMedici();
    private final List <PazienteDTO> pazienti = ModelPazienti.getInstance().getAllPazienti();
    private final List <String[]> prenotazioni = ModelPrenotazioni.getInstance().getAllVisite();


    @Override
    public void setData(Object data) {
        if(data instanceof MedicoDTO) {
            medico = (MedicoDTO) data;
            setNomeMedico(medico);
            creaVbox();
            creaVboxOggi();
        }
    }

        public void setNomeMedico(MedicoDTO medico) {
            nomeMedico.setText(medico.getNome() + " " + medico.getCognome());
    }

    private void creaVbox() {
        mediciSostituiti.getChildren().clear();

        for (MedicoDTO x: medici){
            if (x.getCodiceFiscale().equals(medico.getSostituto1())){
                Label labelNomeMedico1 = new Label(x.getNome() + " " + x.getCognome());
                labelNomeMedico1.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");

                Label labelSpecilita1 = new Label(x.getSpecialita());
                labelSpecilita1.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");

                VBox medicoBox = new VBox(labelNomeMedico1, labelSpecilita1);
                medicoBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
                medicoBox.setSpacing(5);

                medicoBox.prefWidthProperty().bind(mediciSostituiti.widthProperty());
                mediciSostituiti.getChildren().add(medicoBox);

                medicoBox.setOnMouseClicked(event -> {
                    try {
                        paginaPazientiConvenzionati(x);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
            }
        }
        for (MedicoDTO x: medici){
            if (x.getCodiceFiscale().equals(medico.getSostituto2())){
                Label labelNomeMedico2 = new Label(x.getNome() + " " + x.getCognome());
                labelNomeMedico2.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");

                Label labelSpecilita2 = new Label(x.getSpecialita());
                labelSpecilita2.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");

                VBox medicoBox = new VBox(labelNomeMedico2, labelSpecilita2);
                medicoBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
                medicoBox.setSpacing(5);

                medicoBox.prefWidthProperty().bind(mediciSostituiti.widthProperty());
                mediciSostituiti.getChildren().add(medicoBox);

                medicoBox.setOnMouseClicked(event -> {
                    try {
                        paginaPazientiConvenzionati(x);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
            }
        }
    }

        private void paginaPazientiConvenzionati(MedicoDTO medicoSostituito) throws IOException {
        if (medicoSostituito != null){
            List<MedicoDTO> dati = new ArrayList<>();
            dati.add(medico);
            dati.add(medicoSostituito);
            HelloApplication pagina = new HelloApplication();
            pagina.changeSceneWithData("PazientiConvenzionati.fxml", dati);
        }else
            pazientiConvenzionati();
    }

        private void creaVboxOggi() {
        visiteOggi.getChildren().clear(); // Pulisce gli elementi esistenti nella VBox

        // Filtro delle prenotazioni per il medico selezionato e data odierna
        List<String[]> prenotazioniFiltrate = new ArrayList<>();
        LocalDate oggi = LocalDate.now();  // Ottieni la data di oggi

        for (String[] x : prenotazioni) {
            // Filtro per medico e data odierna
            LocalDate dataPrenotazione = LocalDate.parse(x[3], DateTimeFormatter.ofPattern("dd-MM-yyyy"));
            if (x[0].equals(medico.getCodiceFiscale()) && dataPrenotazione.equals(oggi)) {
                prenotazioniFiltrate.add(x);
            }
        }

        // Ordinamento delle prenotazioni per ora (ora decrescente)
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        prenotazioniFiltrate.sort((a, b) -> {
            LocalTime oraA = LocalTime.parse(a[4], timeFormatter);
            LocalTime oraB = LocalTime.parse(b[4], timeFormatter);
            return oraA.compareTo(oraB); // Ordine decrescente per ora
        });

        // Creazione delle VBox per ogni prenotazione
        for (String[] x : prenotazioniFiltrate) {
            PazienteDTO paziente = null;
            for (PazienteDTO y : pazienti) {
                if (y.getCodiceSanitario().equals(x[1])) {
                    paziente = y;
                    break;
                }
            }

            if (paziente != null) {
                HBox prenBox = getPrenBox(x, paziente);
                prenBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
                prenBox.setSpacing(20);

                prenBox.prefWidthProperty().bind(visiteOggi.widthProperty());
                visiteOggi.getChildren().add(prenBox);

                prenBox.setOnMouseClicked(event -> {
                    try {
                        creaVisita(x);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
            }
        }
    }

    private static HBox getPrenBox(String[] x, PazienteDTO paziente) {
        Label labelNomePaziente = new Label(paziente.getNome() + " " + paziente.getCognome());
        labelNomePaziente.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");

        Label labelTipoPrenotazione = new Label(x[2].equals("Adulti") ? "Visita medica" : "Visita pediatrica");
        labelTipoPrenotazione.setStyle("-fx-text-fill: #555;");

        Label labelDataPrenotazione = new Label(" Data: " + x[3]);
        labelDataPrenotazione.setStyle("-fx-text-fill: #555;");

        Label labelOraPrenotazione = new Label(" Ora: " + x[4]);
        labelOraPrenotazione.setStyle("-fx-text-fill: #555;");

        Label labelRegimePrenotazione = new Label(" Regime: " + x[5]);
        labelRegimePrenotazione.setStyle("-fx-text-fill: #555;");

        return new HBox(labelNomePaziente, labelTipoPrenotazione, labelDataPrenotazione, labelOraPrenotazione, labelRegimePrenotazione);
    }

    private void creaVisita(String[] datiPrenotazione) throws IOException {
        List<Object> dati = new ArrayList<>();
        dati.add(medico);
        dati.add(datiPrenotazione[1]); //CS paziente
        dati.add(datiPrenotazione[2]); //tipo di visita
        dati.add(datiPrenotazione[3]); //data visita
        dati.add(datiPrenotazione[4]); //ora visita
        dati.add(datiPrenotazione[5]); //regime
        dati.add(datiPrenotazione[6]); //ambulatorio
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("CreaVisita.fxml", dati);
    }


    @FXML
    public void storicoVisite() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("StoricoReferti.fxml", medico);
    }

    @FXML
    public void pazientiConvenzionati() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("PazientiConvenzionati.fxml", medico);
    }

    @FXML
    public void assenze() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("Assenze.fxml", medico);
}

    @FXML
    public void logOut() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("Login.fxml");
    }


}
