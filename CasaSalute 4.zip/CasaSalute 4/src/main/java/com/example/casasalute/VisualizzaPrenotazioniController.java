package com.example.casasalute;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class VisualizzaPrenotazioniController implements DataReceiver {

    @FXML private VBox storicoPrenotazioni;
    @FXML private Label nomePaziente;
    @FXML private Label titolo;
    private final List<String[]> visite = ModelPrenotazioni.getInstance().getAllVisite();
    private final List<String[]> prestazioni = ModelPrenotazioni.getInstance().getAllPrestazioni();
    private final List<MedicoDTO> medici = ModelMedici.getInstance().getAllMedici();
    private PazienteDTO paziente;
    private PazienteDTO pazienteFiglio;
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    @Override
    public void setData(Object data){
        if (data instanceof PazienteDTO) {
            paziente = (PazienteDTO) data;
            setNomePaziente(paziente);
        } else if (data instanceof ArrayList<?> datiPassati) {
            paziente = (PazienteDTO) datiPassati.getFirst();
            setNomePaziente(paziente);
            pazienteFiglio = (PazienteDTO) datiPassati.getLast();
            titolo.setText("Visualizza prenotazioni di " + pazienteFiglio.getNome() + " " + pazienteFiglio.getCognome());
        }
        creaVbox();
    }

    private void setNomePaziente(PazienteDTO paziente){
        nomePaziente.setText(paziente.getNome() + " " + paziente.getCognome());
    }

    public void creaVbox() {
        storicoPrenotazioni.getChildren().clear();
        List<HBox> elementiOrdinati = new ArrayList<>();

        if (pazienteFiglio != null) {
            for (String[] x : visite) {
                if (x[1].equals(pazienteFiglio.getCodiceSanitario()))
                    elementiOrdinati.add(creaVisiteBox("Visita Pediatrica", x));
            }
            for (String[] x : prestazioni) {
                if (x[1].equals(pazienteFiglio.getCodiceSanitario()))
                    elementiOrdinati.add(creaPrestazioniBox(x));
            }
        } else {
            for (String[] x : visite) {
                if (x[1].equals(paziente.getCodiceSanitario()))
                    elementiOrdinati.add(creaVisiteBox("Visita Medica", x));
            }
            for (String[] x : prestazioni) {
                if (x[1].equals(paziente.getCodiceSanitario()))
                    elementiOrdinati.add(creaPrestazioniBox(x));
            }
        }
        // Ordinamento per data
        elementiOrdinati.sort(Comparator.comparing(vbox -> LocalDate.parse(((Label) vbox.getChildren().get(1)).getText().substring(7), formatter)));
        storicoPrenotazioni.getChildren().addAll(elementiOrdinati);
    }

    private HBox creaVisiteBox(String tipoV, String[] visita){
        Label labelNomeV = new Label(tipoV);
        labelNomeV.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");
        Label labelDataV = new Label(" Data: " + visita[3]);  // Data visita
        labelDataV.setStyle("-fx-text-fill: #555;");
        HBox visitaHBox = getVisitaHBox(visita, labelNomeV, labelDataV);
        visitaHBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
        visitaHBox.setSpacing(20);

        return visitaHBox;
    }

    private HBox getVisitaHBox(String[] visita, Label labelNomeV, Label labelDataV) {
        Label labelOraV = new Label(" Ora: " + visita[4]);  // Ora visita
        labelOraV.setStyle("-fx-text-fill: #555;");
        Label labelCFMedico = null;
        for (MedicoDTO x : medici) {
            if (visita[0].equals(x.getCodiceFiscale())) {
                labelCFMedico = new Label(" Medico: " + x.getNome() + " " + x.getCognome());
                labelCFMedico.setStyle("-fx-text-fill: #555;");
                break;
            }
        }
        Label labelRegimeV = new Label(" Regime: " + visita[5]);  // Regime visita
        labelRegimeV.setStyle("-fx-text-fill: #555;");

        return new HBox(labelNomeV, labelDataV, labelOraV, labelCFMedico, labelRegimeV);
    }

    private HBox creaPrestazioniBox(String[] prestazione){
        Label labelNomeP = new Label(prestazione[0]);
        labelNomeP.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");
        Label labelDataP = new Label(" Data: " + prestazione[2]);
        labelDataP.setStyle("-fx-text-fill: #555;");
        Label labelOraP = new Label(" Ora: " + prestazione[3]);
        labelOraP.setStyle("-fx-text-fill: #555;");
        HBox prestazioneBox = new HBox(labelNomeP, labelDataP, labelOraP);
        prestazioneBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
        prestazioneBox.setSpacing(20);

        return prestazioneBox;
    }

    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        if (pazienteFiglio != null) {
            List<Object> dati = new ArrayList<>();
            dati.add(paziente);
            dati.add(pazienteFiglio);
            pagina.changeSceneWithData("ProfiloFiglio.fxml", dati);
        } else {
            pagina.changeSceneWithData("ProfiloUser.fxml", paziente);
        }
    }
}
