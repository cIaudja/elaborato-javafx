package com.example.casasalute;

public class RefertoDTO {

    private final String codiceReferto;
    private final String nomeReferto;
    private final String dataReferto;
    private String codiceFiscaleMedico;
    private String codiceFiscaleMedicoSostituito;
    private String codiceFiscaleInfermiere;
    private final String codiceSanitarioPaziente;
    private String ambulatorioReferto;
    private  String regimeReferto;
    private String urgenzaReferto;
    private String esitoReferto;
    private String tipoVisita;

    public RefertoDTO(String nomeReferto, String dataReferto, String codiceFiscaleMedico, String codiceFiscaleMedicoSostituito, String codiceSanitarioPaziente, String ambulatorioReferto, String regimeReferto, String urgenzaReferto, String tipoVisita){
        this.codiceReferto = generaCodiceReferto(nomeReferto, dataReferto, codiceFiscaleMedico, codiceSanitarioPaziente);
        this.nomeReferto = nomeReferto;
        this.dataReferto = dataReferto;
        this.codiceFiscaleMedico = codiceFiscaleMedico;
        this.codiceFiscaleMedicoSostituito = codiceFiscaleMedicoSostituito;
        this.codiceSanitarioPaziente = codiceSanitarioPaziente;
        this.ambulatorioReferto = ambulatorioReferto;
        this.regimeReferto = regimeReferto;
        this.urgenzaReferto = urgenzaReferto;
        this.tipoVisita = tipoVisita;
    }

    public RefertoDTO(String nomeReferto, String dataReferto, String codiceFiscaleInfermiere, String codiceSanitarioPaziente, String esitoReferto){
        this.codiceReferto = generaCodiceReferto(nomeReferto, dataReferto, codiceFiscaleInfermiere, codiceSanitarioPaziente);
        this.nomeReferto = nomeReferto;
        this.dataReferto = dataReferto;
        this.codiceFiscaleInfermiere = codiceFiscaleInfermiere;
        this.codiceSanitarioPaziente = codiceSanitarioPaziente;
        this.esitoReferto = esitoReferto;
    }

    private String generaCodiceReferto(String nomeReferto, String dataReferto, String codiceFiscaleMedico, String codiceSanitarioPaziente){
        String dati = nomeReferto.toUpperCase() + dataReferto.toUpperCase() + codiceFiscaleMedico.toUpperCase() + codiceSanitarioPaziente.toUpperCase();
        int hash = dati.hashCode();
        hash = Math.abs(hash);
        return "REF" + String.valueOf(hash).substring(0, 8); // Prende i primi 8 numeri
    }

    public String getCodiceReferto(){
        return codiceReferto;
    }

    public String getNomeReferto() {
        return nomeReferto;
    }

    public String getDataReferto() {
        return dataReferto;
    }

    public String getCodiceFiscaleMedico() {
        return codiceFiscaleMedico;
    }

    public String getCodiceFiscaleMedicoSostituito() {
        return codiceFiscaleMedicoSostituito;
    }

    public String getCodiceFiscaleInfermiere() {
        return codiceFiscaleInfermiere;
    }

    public String getCodiceSanitarioPaziente() {
        return codiceSanitarioPaziente;
    }

    public String getRegimeReferto() {
        return regimeReferto;
    }

    public String getEsitoReferto() {
        return esitoReferto;
    }

    public String getUrgenzaReferto() {
        return urgenzaReferto;
    }

    public String getTipoVisita() {
        return tipoVisita;
    }

    @Override
    public String toString() {
        if (tipoVisita != null && tipoVisita.contains("Visita"))
            return codiceReferto + "\t" +
                    nomeReferto + "\t" +
                    dataReferto + "\t" +
                    codiceFiscaleMedico + "\t" +
                    codiceFiscaleMedicoSostituito + "\t" +
                    codiceSanitarioPaziente + "\t" +
                    ambulatorioReferto + "\t" +
                    regimeReferto + "\t" +
                    urgenzaReferto + "\t" +
                    tipoVisita;
        else if (nomeReferto.contains("Prelievo") || nomeReferto.contains("Medicazione"))
            return codiceReferto + "\t" +
                    nomeReferto + "\t" +
                    dataReferto + "\t" +
                    codiceFiscaleInfermiere + "\t" +
                    codiceSanitarioPaziente + "\t" +
                    esitoReferto;
        else
            return null;
    }
}
