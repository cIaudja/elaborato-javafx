package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import java.io.IOException;
import java.util.*;
import java.util.List;

public class ProfiloUserController implements DataReceiver{

    @FXML private Label nomePaziente;
    @FXML private ListView<MailDTO> mail;
    @FXML private Hyperlink nucleo;
    private final List<MailDTO> mails = ModelMail.getInstance().getAllMail();
    private final List<MailDTO> mailFiltrate = new ArrayList<>();
    private PazienteDTO paziente;

    @Override
    public void setData(Object data) {
        if (data instanceof PazienteDTO) {
            setNomePaziente((PazienteDTO) data);
            paziente = (PazienteDTO) data;
            if (!paziente.getEmailTutore().equals("null"))
                nucleo.setVisible(false);
            for (MailDTO x : mails)
                if ((x.getDestinatario() != null && x.getDestinatario().equals(paziente.getEmail())) || (x.getEmailTutore() != null && x.getEmailTutore().equals(paziente.getEmail())))
                    mailFiltrate.add(x);
            ObservableList<MailDTO> emails = FXCollections.observableArrayList(mailFiltrate);
            mail.setItems(emails);
            mail.setCellFactory(new Callback<>() {
                @Override
                public ListCell<MailDTO> call(ListView<MailDTO> listView) {
                    return new ListCell<>() {
                        @Override
                        protected void updateItem(MailDTO email, boolean empty) {
                            super.updateItem(email, empty);
                            if (empty || email == null) {
                                setText(null);
                                setGraphic(null);
                            } else {
                                VBox emailBox = new VBox();
                                emailBox.setStyle("-fx-padding: 15; -fx-border-color: #007B7F; -fx-border-radius: 5; -fx-background-color: #E0F2F1;");
                                Label labelOggetto = new Label(email.getOggetto() + " disponibile");
                                labelOggetto.setStyle("-fx-font-family: SansSerif; -fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: black;");
                                Label labelMittente = new Label("Mittente: " + email.getMittente());
                                labelMittente.setStyle("-fx-text-fill: #555;");

                                Label labelDestinatario = getLabelDestinatario(email);
                                emailBox.getChildren().addAll(labelOggetto, labelMittente, labelDestinatario);

                                setGraphic(emailBox);
                                setOnMouseClicked(event -> {
                                    if (!isEmpty()) {
                                        email.mostraDettagliEmail(email);
                                    }
                                });
                            }
                        }
                    };
                }
            });
        }
    }
        private static Label getLabelDestinatario(MailDTO email) {
        Label labelDestinatario;
        if (email.getDestinatario().equals("null") && !email.getEmailTutore().equals("null")) {
            labelDestinatario = new Label("Destinatario: " + email.getEmailTutore());
        } else if (!email.getDestinatario().equals("null") && !email.getEmailTutore().equals("null")) {
            labelDestinatario = new Label("Destinatario: " + email.getDestinatario() + "\nTutore: " + email.getEmailTutore());
        } else {
            labelDestinatario = new Label("Destinatario: " + email.getDestinatario());
        }

        labelDestinatario.setStyle("-fx-text-fill: #555;");
        return labelDestinatario;
    }
        private void setNomePaziente (PazienteDTO paziente){
        nomePaziente.setText(paziente.getNome() + " " + paziente.getCognome());
    }

    @FXML
    public void prenotaVisita() throws IOException{
        if (paziente.getMedico().equals("null")) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Medico non assegnato");
            alert.setHeaderText(null);
            alert.setContentText("La segreteria non ha ancora assegnato un medico curante. L'assegnazione potrebbe richiedere alcuni giorni. In caso di problemi, contatta il Contact Center al numero verde 800.030.606 (attivo dal lunedì al venerdì, dalle 8:00 alle 18:00).");
            alert.showAndWait();
        } else {
            HelloApplication pagina = new HelloApplication();
            pagina.changeSceneWithData("PrenotaVisita.fxml", paziente);
        }
    }
    @FXML
    public void prenotaPrestazione() throws IOException{
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("PrenotaPrestazione.fxml", paziente);
    }
    @FXML
    public void nucleoFamiliare() throws IOException{
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("NucleoFamiliare.fxml", paziente);
    }
    @FXML
    public void visualizzaPrenotazioni() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("VisualizzaPrenotazioni.fxml", paziente);
    }
    @FXML
    public void visualizzaResoconto() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("Resoconto.fxml", paziente);
    }
    @FXML
    public void logOut() throws IOException{
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("Login.fxml");
    }
}
