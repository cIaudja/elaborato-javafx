package com.example.casasalute;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.Region;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

public class MailDTO {
    private final String oggetto;
    private final String mittente;
    private final String destinatario;
    private final String emailTutore;
    private final String corpo;

    public MailDTO(String oggetto, String destinatario, String emailTutore, String corpo) {
        this.oggetto = oggetto;
        this.mittente = "segreteria@casaSalute.it";
        this.destinatario = destinatario;
        this.emailTutore = emailTutore.toLowerCase();
        this.corpo = corpo;
    }

    public void mostraDettagliEmail(MailDTO email) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Dettagli Email");
        alert.setHeaderText(null);

        // Titolo principale
        Text titolo = new Text("Dettagli Email\n\n");
        titolo.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");

        // Oggetto
        Text oggetto = new Text("Oggetto: ");
        oggetto.setStyle("-fx-font-weight: bold;");
        Text oggettoValore = new Text(email.getOggetto() + " disponibile\n");

        // Mittente
        Text mittente = new Text("Mittente: ");
        mittente.setStyle("-fx-font-weight: bold;");
        Text mittenteValore = new Text(email.getMittente() + "\n");

        // Destinatario (in base all'età)
        TextFlow destinatariFlow;

        Text destinatarioLabel = new Text("Destinatario: ");
        destinatarioLabel.setStyle("-fx-font-weight: bold;");
        if (email.getDestinatario().equals("null") && !email.getEmailTutore().equals("null")) {
            Text tutoreValore = new Text(email.getEmailTutore() + "\n\n");
            destinatariFlow = new TextFlow(tutoreValore);

        } else if (!email.getDestinatario().equals("null") && !email.getEmailTutore().equals("null")) {
            Text destValore = new Text(email.getDestinatario());
            Text tutoreLabel = new Text("\nTutore: ");
            tutoreLabel.setStyle("-fx-font-weight: bold;");
            Text tutoreValore = new Text(email.getEmailTutore() + "\n\n");
            destinatariFlow = new TextFlow(destValore, tutoreLabel, tutoreValore);

        } else {
            Text destinatarioValore = new Text(email.getDestinatario() + "\n\n");
            destinatariFlow = new TextFlow(destinatarioValore);
        }

        // Messaggio
        Text messaggio = new Text("\nMessaggio:\n");
        messaggio.setStyle("-fx-font-weight: bold;");
        Text messaggioValore = new Text(email.getCorpo() + "\n\n");

        // Messaggio automatico
        Text messaggioAutomatico = new Text("📌 Messaggio Automatico:\n");
        messaggioAutomatico.setStyle("-fx-font-weight: bold;");
        Text messaggioAutomaticoValore = new Text(
                "La trasmissione avviene automaticamente all'indirizzo email che ha comunicato al portale.\n\n"
        );

        // Supporto
        Text supporto = new Text("📞 Per supporto:\n");
        supporto.setStyle("-fx-font-weight: bold;");
        Text supportoValore = new Text(
                "Contatti il Contact Center al numero verde 800.030.606 (attivo dal lunedì al venerdì, dalle 8:00 alle 18:00)."
        );

        // Creazione del TextFlow con i dati
        TextFlow textFlow = new TextFlow(
                titolo, oggetto, oggettoValore,
                mittente, mittenteValore,
                destinatarioLabel, destinatariFlow,
                messaggio, messaggioValore,
                messaggioAutomatico, messaggioAutomaticoValore,
                supporto, supportoValore
        );
        alert.getDialogPane().setContent(textFlow);
        alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        alert.getDialogPane().setMinWidth(450);
        alert.setGraphic(null);
        alert.getButtonTypes().setAll(ButtonType.OK);
        alert.showAndWait();
    }

    public String getOggetto() { return oggetto; }
    public String getMittente() { return mittente; }
    public String getDestinatario() { return destinatario; }
    public String getEmailTutore() { return emailTutore; }
    public String getCorpo() { return corpo; }

    @Override
    public String toString() {
        return this.oggetto + "\t" +
                this.mittente + "\t" +
                this.destinatario + "\t" +
                this.emailTutore + "\t" +
                this.corpo;
    }
}
