package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class PazientiConvenzionatiController implements Initializable, DataReceiver {

    private MedicoDTO medico;
    private MedicoDTO medicoSostituito;
    private List<PazienteDTO> pazienti;
    @FXML private Label nomeMedico;
    @FXML private Label titolo;
    @FXML private TableView<PazienteDTO> tabella;
    @FXML private TableColumn<PazienteDTO, String> cs;
    @FXML private TableColumn<PazienteDTO, String> nome;
    @FXML private TableColumn<PazienteDTO, String> cognome;
    @FXML private TableColumn<PazienteDTO, String> data;
    @FXML private TableColumn<PazienteDTO, String> luogo;
    @FXML private TableColumn<PazienteDTO, String> email;
    @FXML private TableColumn<PazienteDTO, String> password;
    @FXML private TableColumn<PazienteDTO, String> emailTut;

    @Override
    public void setData(Object data) {
        if (data instanceof MedicoDTO) {
            medico = (MedicoDTO) data;
            nomeMedico.setText(medico.getNome() + " " + medico.getCognome());
            creaTabella();
        }
        else if (data instanceof ArrayList<?> datiPassati) {
            medico = (MedicoDTO) datiPassati.getFirst();
            nomeMedico.setText(medico.getNome() + " " + medico.getCognome());
            medicoSostituito = (MedicoDTO) datiPassati.getLast();
            setTitolo(medicoSostituito);
            creaTabella();
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        pazienti = ModelPazienti.getInstance().getAllPazienti();
    }

    public void setTitolo(MedicoDTO medicoSostituito){
        titolo.setText("Pazienti convenzionati di medico " + medicoSostituito.getNome() + " " + medicoSostituito.getCognome());
    }

    public void creaTabella(){
        cs.setCellValueFactory(new PropertyValueFactory<>("codiceSanitario"));
        nome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        cognome.setCellValueFactory(new PropertyValueFactory<>("cognome"));
        data.setCellValueFactory(new PropertyValueFactory<>("data"));
        luogo.setCellValueFactory(new PropertyValueFactory<>("luogo"));
        email.setCellValueFactory(new PropertyValueFactory<>("email"));
        password.setCellValueFactory(new PropertyValueFactory<>("password"));
        emailTut.setCellValueFactory(new PropertyValueFactory<>("emailTutore"));

        List<PazienteDTO> pazientiConvenzionati = new ArrayList<>();
        if (medicoSostituito != null) {
            for (PazienteDTO x : pazienti) {
                if (x.getMedico().equals(medicoSostituito.getCodiceFiscale()))
                    pazientiConvenzionati.add(x);
            }
        }else {
            for (PazienteDTO x : pazienti) {
                if (x.getMedico().equals(medico.getCodiceFiscale()))
                    pazientiConvenzionati.add(x);
            }
        }

        ObservableList<PazienteDTO> pazientiObservable = FXCollections.observableList(pazientiConvenzionati);
        tabella.setItems(pazientiObservable);

        // Gestione click sulla riga della tabella
        tabella.setRowFactory(tv -> {
            TableRow<PazienteDTO> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (!row.isEmpty() && event.getClickCount() == 1) { // Click singolo
                    PazienteDTO selectedPaziente = row.getItem();
                    try {
                        handleRowClick(selectedPaziente);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            return row;
        });
    }

    //metodo per gestire il click sulla tabella
    private void handleRowClick(PazienteDTO paziente) throws IOException {
        List<Object> dati = new ArrayList<>();
        dati.add(medico);
        dati.add(paziente);
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("Resoconto.fxml", dati);
    }


    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("ProfiloMedico.fxml", medico);
    }
}




