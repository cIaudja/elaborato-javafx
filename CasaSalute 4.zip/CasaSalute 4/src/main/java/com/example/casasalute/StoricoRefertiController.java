package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.List;

public class StoricoRefertiController implements DataReceiver {

    @FXML private Label nome;
    @FXML private Label titolo;
    @FXML private VBox referti;
    @FXML private Label titolo2;
    @FXML private Button bottonePrenotazione;
    @FXML private ChoiceBox<String> annoReferto;
    private MedicoDTO medico;
    private InfermiereDTO infermiere;
    private PazienteDTO paziente;
    private final List<RefertoDTO> Allreferti = ModelReferti.getInstance().getAllReferti();
    private final List<RefertoDTO> refertiFiltrati = new ArrayList<>();
    private final List<PazienteDTO> pazienti = ModelPazienti.getInstance().getAllPazienti();

    @Override
    public void setData(Object data) {
        referti.getChildren().clear();
        refertiFiltrati.clear();

        if (data instanceof MedicoDTO medicoDTO) {
            setNomeMedico(medicoDTO);
            medico = medicoDTO;
            filtraRefertiMedico();
        } else if (data instanceof InfermiereDTO infermiereDTO) {
            infermiere = infermiereDTO;
            setNomeInfermiere();
            filtraRefertiInfermiere();
        }

        refertiFiltrati.sort((a, b) -> b.getDataReferto().compareTo(a.getDataReferto()));
        popolaTendina();
        aggiornaListaReferti(refertiFiltrati);
    }

    private void filtraRefertiMedico() {
        for (RefertoDTO x : Allreferti) {
            if (x.getCodiceFiscaleMedico() != null && (x.getCodiceFiscaleMedico().equals(medico.getCodiceFiscale()) ||
                    (x.getCodiceFiscaleMedicoSostituito() != null && x.getCodiceFiscaleMedicoSostituito().equals(medico.getCodiceFiscale())))) {
                refertiFiltrati.add(x);
            }
        }
    }

    private void filtraRefertiInfermiere() {
        for (RefertoDTO x : Allreferti) {
            if (x.getCodiceFiscaleInfermiere() != null && x.getCodiceFiscaleInfermiere().equals(infermiere.getCodiceFiscale())) {
                refertiFiltrati.add(x);
            }
        }
    }

    public void popolaTendina() {
        Set<String> anniUnici = new TreeSet<>();
        for (RefertoDTO x : refertiFiltrati) {
            String anno = x.getDataReferto().split("-")[2]; // Estrai solo l'anno
            anniUnici.add(anno);
        }
        List<String> opzioniAnni = new ArrayList<>(anniUnici);
        opzioniAnni.add(0, "Filtra per anno");
        annoReferto.setItems(FXCollections.observableArrayList(opzioniAnni));
        annoReferto.setValue("Filtra per anno");

        annoReferto.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && !newValue.equals("Filtra per anno")) {
                filtraRefertiPerAnno(newValue);
            } else {
                aggiornaListaReferti(refertiFiltrati);
            }
        });
    }

    private void filtraRefertiPerAnno(String anno) {
        List<RefertoDTO> refertiFiltratiPerAnno = refertiFiltrati.stream()
                .filter(referto -> referto.getDataReferto().endsWith(anno))
                .toList();
        aggiornaListaReferti(refertiFiltratiPerAnno);
    }

    private void aggiornaListaReferti(List<RefertoDTO> refertiDaMostrare) {
        referti.getChildren().clear();
        for (RefertoDTO x : refertiDaMostrare) {
            if (medico != null) {
                referti.getChildren().add(creaVboxReferto(x, true));
            } else if (infermiere != null) {
                referti.getChildren().add(creaVboxReferto(x, false));
            }
        }
    }

    private void setNomeMedico(MedicoDTO medico) {
        titolo.setText("MEDICO");
        nome.setText(medico.getNome() + " " + medico.getCognome());
        titolo2.setText("Storico visite");
        bottonePrenotazione.setText("Inserisci visita");
    }

    private void setNomeInfermiere() {
        titolo.setText("INFERMIERE");
        nome.setText(infermiere.getNome() + " " + infermiere.getCognome());
        titolo2.setText("Storico prestazioni");
        bottonePrenotazione.setText("Inserisci prestazione");
    }

    private VBox creaVboxReferto(RefertoDTO x, boolean isMedico) {
        Label labelNomeReferto = new Label(x.getNomeReferto());
        labelNomeReferto.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");
        Label labelDataReferto = new Label(" Data: " + x.getDataReferto());
        labelDataReferto.setStyle("-fx-text-fill: #555;");

        for (PazienteDTO y : pazienti) {
            if (y.getCodiceSanitario().equals(x.getCodiceSanitarioPaziente())) {
                paziente = y;
                break;
            }
        }
        Label labelPaziente = new Label(" Paziente: " + paziente.getNome() + " " + paziente.getCognome());
        labelPaziente.setStyle("-fx-text-fill: #555;");

        VBox refertoBox = isMedico
                ? new VBox(labelNomeReferto, labelDataReferto, labelPaziente)
                : new VBox(labelNomeReferto, new Label(" Codice: " + x.getCodiceReferto()), labelDataReferto, labelPaziente);

        refertoBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
        refertoBox.setSpacing(5);
        refertoBox.prefWidthProperty().bind(referti.widthProperty());
        refertoBox.setOnMouseClicked(event -> apriPdf(x.getCodiceReferto()));
        return refertoBox;
    }

    private void apriPdf(String codiceReferto) {
        Allreferti.stream()
                .filter(x -> x.getCodiceReferto().equals(codiceReferto))
                .findFirst()
                .ifPresent(x -> {
                    File file = new File("src/main/pdf/" + x.getNomeReferto());
                    if (file.exists() && Desktop.isDesktopSupported()) {
                        try {
                            Desktop.getDesktop().open(file);
                        } catch (IOException e) {
                            System.err.println("Errore nell'aprire il PDF: " + e.getMessage());
                        }
                    } else {
                        System.err.println("Il file PDF non esiste o il Desktop non è supportato.");
                    }
                });
    }

    @FXML
    public void prenotazioni() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("RefertiPrenotazioni.fxml", medico != null ? medico : infermiere);
    }

    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData(medico != null ? "ProfiloMedico.fxml" : "ProfiloInfermiere.fxml", medico != null ? medico : infermiere);
    }

}




