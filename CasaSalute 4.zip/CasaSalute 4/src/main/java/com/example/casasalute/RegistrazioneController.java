package com.example.casasalute;

import javafx.scene.control.Alert;
import javafx.scene.control.TextInputDialog;

import java.util.List;
import java.util.Optional;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.io.IOException;
import java.time.format.DateTimeParseException;

public class RegistrazioneController {

    @FXML private Label errore;
    @FXML private TextField nome;
    @FXML private TextField cognome;
    @FXML private TextField luogo;
    @FXML private TextField data;
    @FXML private TextField email;
    @FXML private TextField password;
    private final List<PazienteDTO> pazienti = ModelPazienti.getInstance().getAllPazienti();

    @FXML
    public void registrati() throws IOException {
        HelloApplication pagina = new HelloApplication();
        String nomeText = nome.getText();
        String cognomeText = cognome.getText();
        String luogoText = luogo.getText();
        String dataText = data.getText();
        String emailText = email.getText();
        String passwordText = password.getText();

        if (nomeText.isEmpty() || cognomeText.isEmpty() || luogoText.isEmpty() || dataText.isEmpty() || emailText.isEmpty() || passwordText.isEmpty()) {
            errore.setText("Tutti i campi devono essere compilati!");
            return;
        }
        if (!emailText.matches("^[\\w.-]+@[a-zA-Z\\d.-]+\\.[a-zA-Z]{2,}$")) {
            errore.setText("Inserire una mail valida!");
            return;
        }
        if (!dataText.matches("\\d{2}/\\d{2}/\\d{4}")) {
            errore.setText("La data deve essere nel formato gg/mm/aaaa!");
            return;
        }
        try {
            int eta = calcolaEta(dataText);
            if (eta < 14 || eta > 110) {
                errore.setText("Età non valida!");
                return;
            }
            PazienteDTO nuovoPaziente = new PazienteDTO(nomeText, cognomeText, dataText, luogoText, emailText, passwordText, "null", "null", "null");
            for (PazienteDTO x : pazienti)
                if (x.getCodiceSanitario().equals(nuovoPaziente.getCodiceSanitario()))
                {
                    errore.setText("Questo paziente esiste già!");
                    return;
                }
            ModelPazienti.aggiungiPaziente(nuovoPaziente);
            if (eta < 18) {
                richiediEmailTutore();
            } else {
                pagina.changeSceneWithData("ProfiloUser.fxml", nuovoPaziente);
            }
        } catch (DateTimeParseException e) {
            errore.setText("Età non valida!");
        }
    }

    private int calcolaEta(String dataNascita) {
        String[] partiData = dataNascita.split("/");
        int giornoNascita = Integer.parseInt(partiData[0]);
        int meseNascita = Integer.parseInt(partiData[1]);
        int annoNascita = Integer.parseInt(partiData[2]);
        java.util.Calendar oggi = java.util.Calendar.getInstance();
        int annoCorrente = oggi.get(java.util.Calendar.YEAR);
        int meseCorrente = oggi.get(java.util.Calendar.MONTH) + 1;
        int giornoCorrente = oggi.get(java.util.Calendar.DAY_OF_MONTH);
        int eta = annoCorrente - annoNascita;
        if (meseCorrente < meseNascita || (meseCorrente == meseNascita && giornoCorrente < giornoNascita)) {
            eta--;
        }
        return eta;
    }

    @FXML
    public void accedi() throws IOException{
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("Login.fxml");
    }

    public void richiediEmailTutore() {
        Optional<String> result = getString();
        result.ifPresent(emailInserita -> {
            if (!emailInserita.matches("^[\\w.-]+@[a-zA-Z\\d.-]+\\.[a-zA-Z]{2,}$")) {
                Alert erroreAlert = new Alert(Alert.AlertType.ERROR);
                erroreAlert.setTitle("Errore");
                erroreAlert.setHeaderText(null);
                erroreAlert.setContentText("Inserire un'email valida!");
                erroreAlert.showAndWait();
                richiediEmailTutore();
            } else {
                try {
                    ModelPazienti model = ModelPazienti.getInstance();
                    PazienteDTO ultimoPaziente = model.getAllPazienti().getLast();
                    ultimoPaziente.setEmailTutore(emailInserita);
                    HelloApplication pagina = new HelloApplication();
                    PazienteDTO ultimoPazienteAggiornato = model.getAllPazienti().getLast();
                    ModelPazienti.aggiornaFile();
                    pagina.changeSceneWithData("ProfiloUser.fxml", ultimoPazienteAggiornato);
                } catch (IOException e) {
                    System.out.println("Non è stato possibile inserire l'email del tutore: "+ e);
                }
            }
        });
    }

    private static Optional<String> getString() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Email Tutore");
        dialog.setHeaderText("""
                Per completare la registrazione e usufruire di tutti i servizi
                offerti dalla Casa della Salute, è necessario che un tutore
                legale (genitore o altro responsabile) fornisca il proprio
                indirizzo email. Questo ci permette di comunicare in modo
                efficace riguardo alle prenotazioni e agli esiti delle
                visite relative al minore.""");
        dialog.setContentText("Inserisci l'email del tutore:");

            return dialog.showAndWait();
    }
}
