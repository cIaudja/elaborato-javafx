package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;


import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class ModificaMedicoController implements Initializable, DataReceiver {

    @FXML private Label nomeMedico;
    @FXML private Label cfText;
    @FXML private Label nomeText;
    @FXML private Label cognomeText;
    @FXML private TextField emailText;
    @FXML private TextField passwordText;
    @FXML private TextArea specialitaText;
    @FXML private ChoiceBox<String> sostituto1Text;
    @FXML private ChoiceBox<String> sostituto2Text;
    @FXML private Label errore;
    private final List<MedicoDTO> medici = ModelMedici.getInstance().getAllMedici();
    private final List<String> codiceMedici = new ArrayList<>();
    private MedicoDTO medico;
    private MedicoDTO sostituto1;
    private MedicoDTO sostituto2;
    private String codice;

    @Override
    public void setData(Object data) {
        if (data instanceof MedicoDTO) {
            medico = (MedicoDTO) data;
            nomeMedico.setText(medico.getNome() + " " + medico.getCognome());
            datiMedico(medico);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        for (MedicoDTO x : medici) {
            codiceMedici.add(x.getNome() + " " + x.getCognome());
        }
            sostituto1Text.setItems(FXCollections.observableArrayList(codiceMedici));
            sostituto1Text.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
                if (newValue != null) {
                    List<String> opzioniFiltrate = new ArrayList<>(codiceMedici);
                    opzioniFiltrate.remove(newValue);
                    sostituto2Text.setItems(FXCollections.observableArrayList(opzioniFiltrate));
                } else {
                    sostituto2Text.setItems(FXCollections.observableArrayList(codiceMedici));
                }
            });
    }

    private void datiMedico(MedicoDTO medico){
        cfText.setText(medico.getCodiceFiscale());
        nomeText.setText(medico.getNome());
        cognomeText.setText(medico.getCognome());
        emailText.setText(medico.getEmail());
        passwordText.setText(medico.getPassword());
        specialitaText.setText(medico.getSpecialita());
        for (MedicoDTO x : medici) {
            if (x.getCodiceFiscale().equals(medico.getSostituto1()))
                sostituto1 = x;
            if (x.getCodiceFiscale().equals(medico.getSostituto2()))
                sostituto2 = x;
        }
        sostituto1Text.setValue(sostituto1.getNome() + " " + sostituto1.getCognome());
        sostituto2Text.setValue(sostituto2.getNome() + " " + sostituto2.getCognome());
    }

    @FXML
    private void modificaMedico() throws IOException {
        codice = medico.getCodiceFiscale();
        if (controlliValidazione()) {
            if (codice != null && !codice.isEmpty()) {
                List<MedicoDTO> medici = ModelMedici.getInstance().getAllMedici();
                MedicoDTO medicoTrovato = medici.stream()
                        .filter(p -> p.getCodiceFiscale().equalsIgnoreCase(codice))
                        .findFirst()
                        .orElse(null);

                if (medicoTrovato != null) {
                    medicoTrovato.setCodiceFiscale(cfText.getText());
                    medicoTrovato.setNome(nomeText.getText());
                    medicoTrovato.setCognome(cognomeText.getText());
                    medicoTrovato.setEmail(emailText.getText());
                    medicoTrovato.setPassword(passwordText.getText());
                    medicoTrovato.setSpecialita(specialitaText.getText());
                    for (MedicoDTO x : medici) {
                        if (sostituto1Text.getValue().equals(x.getNome() + " " + x.getCognome()))
                            sostituto1 = x;
                        if (sostituto2Text.getValue().equals(x.getNome() + " " + x.getCognome()))
                            sostituto2 = x;
                    }
                    medicoTrovato.setSostituto1(sostituto1.getCodiceFiscale());
                    medicoTrovato.setSostituto2(sostituto2.getCodiceFiscale());
                    ModelMedici.getInstance().aggiornaFile();
                    HelloApplication pagina = new HelloApplication();
                    pagina.changeScene("VisualizzaDatiMedico.fxml");
                } else {
                    System.out.println("Errore: Medico non trovato.");
                }
            } else {
                System.out.println("Errore: Codice sanitario non valido.");
            }
        }
    }

    private boolean controlliValidazione() {
        if (cfText.getText().isEmpty() || nomeText.getText().isEmpty() || cognomeText.getText().isEmpty() || emailText.getText().isEmpty() || passwordText.getText().isEmpty()) {
            errore.setText("Tutti i campi devono essere compilati!");
            return false;
        }
        if (!emailText.getText().matches("^[\\w.-]+@[a-zA-Z\\d.-]+\\.[a-zA-Z]{2,}$")) {
            errore.setText("L'email non è valida. Assicurati che sia nel formato corretto.");
            return false;
        }
        return validaCodiceFiscale();
    }

    private boolean validaCodiceFiscale() {
        String cf = cfText.getText().toUpperCase();
        if (!cf.matches("^[A-Z]{6}\\d{2}[A-EHLMPRST]\\d{2}[A-Z]\\d{3}[A-Z]$")) {
            errore.setText("Il codice fiscale non è valido. Controlla che sia nel formato corretto.");
            return false;
        }
        char mese = cf.charAt(8);
        if ("ABCDEHLMPRST".indexOf(mese) == -1) {
            errore.setText("Il mese di nascita nel codice fiscale non è valido.");
            return false;
        }
        return true;
    }

    @FXML
    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("VisualizzaDatiMedico.fxml");
    }
}
