package com.example.casasalute;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ModelTurni {

    private static ModelTurni instance;
    private static final String FILE_PATH = "src/main/txt/turni.txt";
    private static final List<TurnoDTO> turni = new ArrayList<>();

    public static ModelTurni getInstance() {
        if (instance == null) {
            instance = new ModelTurni();
        }
        return instance;
    }

    ModelTurni() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] dati = line.split("\t");
                if (dati.length == 3){
                 TurnoDTO turno = new TurnoDTO(
                         dati[0], //cf infermiere
                         dati[1], //giorno
                         dati[2]  //sala
                 );
                 turni.add(turno);
                }
            }
        } catch (IOException e) {
            System.err.println("Nessun file turni trovato: " + e);
        }
    }

    public void aggiungiTurno(TurnoDTO turno) {
        turni.add(turno);
        aggiornaFile();
    }

    public void aggiornaTurniInfermiere(String codiceFiscale, List<TurnoDTO> nuoviTurni) {
        turni.removeIf(turno -> turno.getCodiceFiscaleInfermiere().equals(codiceFiscale));
        turni.addAll(nuoviTurni);
        aggiornaFile();
    }

    public static void aggiornaFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (TurnoDTO x : turni) {
                writer.write(x.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Errore durante l'aggiornamento del file: " + e.getMessage());
        }
    }

    public List<TurnoDTO> getTurniInfermiere(String codiceFiscale) {
        List<TurnoDTO> turniInfermiere = new ArrayList<>();
        for (TurnoDTO turno : turni) {
            if (turno.getCodiceFiscaleInfermiere().equals(codiceFiscale)) {
                turniInfermiere.add(turno);
            }
        }
        return turniInfermiere;
    }

}
