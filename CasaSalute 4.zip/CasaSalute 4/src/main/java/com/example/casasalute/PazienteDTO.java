package com.example.casasalute;

public class PazienteDTO {
    private String codiceSanitario;
    private String nome;
    private String cognome;
    private String password;
    private String data;
    private String luogo;
    private String emailTutore;
    private String email;
    private String medico;
    private final String CSTutore;

    public PazienteDTO(String nome, String cognome, String data, String luogo, String email, String password, String emailTutore, String medico, String CSTutore) {
        this.codiceSanitario = generaCodiceSanitario(nome, cognome, data, luogo);
        this.nome = nome;
        this.cognome = cognome;
        this.data = data;
        this.luogo = luogo;
        this.email = email;
        this.password = password;
        this.emailTutore = emailTutore;
        this.medico = medico;
        this.CSTutore = CSTutore;
    }
        private String generaCodiceSanitario(String nome, String cognome, String data, String luogo) {
        String dataStandardizzata = data.replaceAll("[^0-9]", ""); // Rimuove tutto tranne i numeri
        String dati = nome.toUpperCase() + cognome.toUpperCase() + dataStandardizzata + luogo.toUpperCase();
        int hash = dati.hashCode();
        hash = Math.abs(hash);
        return "CS" + String.valueOf(hash).substring(0, 8); // Prende i primi 8 numeri
        }


    // Getter e Setter per gli attributi
    public String getCodiceSanitario() {
        return codiceSanitario;
    }
    public void setCodiceSanitario(String codiceSanitario) {
        this.codiceSanitario = codiceSanitario;
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }
    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }

    public String getLuogo() {
        return luogo;
    }
    public void setLuogo(String luogo) {
        this.luogo = luogo;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmailTutore() {
        return emailTutore;
    }
    public void setEmailTutore(String emailTutore) {
        this.emailTutore = emailTutore;
    }

    public String getMedico() {
        return medico;
    }
    public void setMedico(String medico) {
        this.medico = medico;
    }

    public String getCSTutore() {
        return CSTutore;
    }

    @Override
    public String toString() {
        return this.codiceSanitario + "\t" +
                this.nome + "\t" +
                this.cognome + "\t" +
                this.data + "\t" +
                this.luogo + "\t" +
                this.email + "\t" +
                this.password + "\t" +
                this.emailTutore + "\t" +
                this.medico + "\t" +
                this.CSTutore;
    }
}