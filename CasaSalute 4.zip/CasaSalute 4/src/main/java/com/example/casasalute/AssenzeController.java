package com.example.casasalute;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import java.io.IOException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.stream.IntStream;

public class AssenzeController implements DataReceiver {

    @FXML private GridPane grigliaCalendario;
    @FXML private Label nomeMedico;
    @FXML private Label errore;
    @FXML private ChoiceBox<Integer> selettoreAnno;
    private Set<LocalDate> assenze = new HashSet<>();
    private MedicoDTO medico;
    private final int annoCorrente = LocalDate.now().getYear();

    @Override
    public void setData(Object data) {
        if (data instanceof MedicoDTO) {
            medico = (MedicoDTO) data;
            setNomeMedico(medico);
            assenze = ModelAssenze.getInstance().getAllAssenze(medico.getCodiceFiscale());
        }
        popolaSelettoreAnno();
        popolaCalendario(annoCorrente);
    }

    private void popolaSelettoreAnno() {
        selettoreAnno.getItems().clear();
        IntStream.range(annoCorrente - 5, annoCorrente + 6).forEach(selettoreAnno.getItems()::add);
        selettoreAnno.setValue(annoCorrente);
        selettoreAnno.setOnAction(e -> popolaCalendario(selettoreAnno.getValue()));
    }

    public void setNomeMedico(MedicoDTO medico) {
        nomeMedico.setText(medico.getNome() + " " + medico.getCognome());
    }

    private void popolaCalendario(int anno) {
        grigliaCalendario.getChildren().clear();
        for (int mese = 0; mese < 12; mese++) {
            String nomeMese = YearMonth.of(anno, mese + 1).getMonth().getDisplayName(TextStyle.FULL, Locale.ITALIAN);
            nomeMese = nomeMese.substring(0, 1).toUpperCase() + nomeMese.substring(1); // Prima lettera maiuscola

            Label labelMese = new Label(nomeMese);
            labelMese.setStyle("-fx-font-size: 14px;");
            labelMese.setAlignment(Pos.CENTER);

            VBox vbox = new VBox(5, labelMese, creaCalendarioMese(YearMonth.of(anno, mese + 1))); // Spaziatura migliorata
            vbox.setAlignment(Pos.CENTER);

            grigliaCalendario.add(vbox, mese % 4, mese / 4);
        }
    }


    private GridPane creaCalendarioMese(YearMonth mese) {
        GridPane calendario = new GridPane();
        calendario.setHgap(2);
        calendario.setVgap(2);
        int giorni = mese.lengthOfMonth();
        int primoGiornoSettimana = mese.atDay(1).getDayOfWeek().getValue(); // Lunedì = 1
        int col = primoGiornoSettimana - 1;
        int row = 1;

        for (int giorno = 1; giorno <= giorni; giorno++) {
            LocalDate data = mese.atDay(giorno);
            Button giornoBtn = new Button(String.valueOf(giorno));
            giornoBtn.setMinSize(25, 25);
            giornoBtn.setStyle("-fx-font-size: 12px; -fx-padding: 2px; -fx-background-color: white;");

            if (assenze.contains(data)) {
                giornoBtn.setStyle("-fx-font-size: 12px; -fx-padding: 2px; -fx-background-color: red;");
            }

            if (data.isBefore(LocalDate.now()) || data.getDayOfWeek().getValue() >= 6) {
                giornoBtn.setDisable(true);
            } else {
                giornoBtn.setOnAction(e -> toggleAssenza(giornoBtn, data));
            }

            calendario.add(giornoBtn, col, row);
            col++;
            if (col == 7) {
                col = 0;
                row++;
            }
        }
        return calendario;
    }

    private void toggleAssenza(Button giornoBtn, LocalDate data) {
        int annoAssenza = data.getYear();
        long assenzeAnno = assenze.stream().filter(d -> d.getYear() == annoAssenza).count();

        if (assenze.contains(data)) {
            assenze.remove(data);
            giornoBtn.setStyle("-fx-background-color: white; -fx-font-size: 12px; -fx-padding: 2px; -fx-min-width: 25px; -fx-min-height: 25px;");
        } else {
            if (assenzeAnno < 28) {
                assenze.add(data);
                giornoBtn.setStyle("-fx-background-color: red; -fx-font-size: 12px; -fx-padding: 2px; -fx-min-width: 25px; -fx-min-height: 25px;");
            } else {
                errore.setText("Limite massimo di 28 assenze per anno raggiunto");
            }
        }
    }

    @FXML void salva() throws IOException {
        ModelAssenze.getInstance().aggiungiAssenze(medico.getCodiceFiscale(), assenze);
        new HelloApplication().changeSceneWithData("ProfiloMedico.fxml", medico);
    }

    @FXML
    public void back() throws IOException {
        new HelloApplication().changeSceneWithData("ProfiloMedico.fxml", medico);
    }
}
