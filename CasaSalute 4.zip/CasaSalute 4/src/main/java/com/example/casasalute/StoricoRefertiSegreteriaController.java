package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.List;

public class StoricoRefertiSegreteriaController implements Initializable {

    @FXML private ChoiceBox<String> annoReferto;
    @FXML private VBox refertiVBox;
    private final List<RefertoDTO> referti = ModelReferti.getInstance().getAllReferti();
    private final List<MedicoDTO> medici = ModelMedici.getInstance().getAllMedici();
    private final List<PazienteDTO> pazienti = ModelPazienti.getInstance().getAllPazienti();
    private final List<InfermiereDTO> infermieri = ModelInfermieri.getInstance().getAllInfermieri();
    private InfermiereDTO infermiere;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        Set<String> anniUnici = new TreeSet<>();
        for (RefertoDTO x : referti) {
            String data = x.getDataReferto(); // Formato gg-mm-aaaa
            String anno = data.split("-")[2]; // Estrai solo l'anno
            anniUnici.add(anno);
        }
        List<String> opzioniAnni = new ArrayList<>(anniUnici);
        opzioniAnni.add(0, "Filtra per anno"); // Opzione iniziale
        annoReferto.setItems(FXCollections.observableArrayList(opzioniAnni));
        annoReferto.setValue("Filtra per anno");

        annoReferto.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                aggiornaVbox(newValue);
            }
        });

        creaVbox(referti);
    }

    public void aggiornaVbox(String annoSelezionato) {
        if (annoSelezionato.equals("Filtra per anno")) {
            creaVbox(referti);
        } else {
            List<RefertoDTO> refertiFiltrati = new ArrayList<>();
            for (RefertoDTO referto : referti) {
                if (referto.getDataReferto().split("-")[2].equals(annoSelezionato)) {
                    refertiFiltrati.add(referto);
                }
            }
            creaVbox(refertiFiltrati);
        }
    }

    public void creaVbox(List<RefertoDTO> listaReferti) {
        refertiVBox.getChildren().clear();
        for (RefertoDTO x : listaReferti) {
            VBox refertoBox = new VBox();
            Label labelNomeReferto = new Label(x.getNomeReferto());
            labelNomeReferto.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");
            Label labelCodiceReferto = new Label(" Codice: " + x.getCodiceReferto());
            labelCodiceReferto.setStyle("-fx-text-fill: #555;");
            Label labelDataReferto = new Label(" Data: " + x.getDataReferto());
            labelDataReferto.setStyle("-fx-text-fill: #555;");
            Label labelPaziente = new Label();
            for (PazienteDTO p : pazienti)
                if (x.getCodiceSanitarioPaziente().equals(p.getCodiceSanitario()))
                    labelPaziente = new Label(" Paziente: " + p.getNome() + " " + p.getCognome());
            labelPaziente.setStyle("-fx-text-fill: #555;");

            if (x.getNomeReferto().contains("Visita")) {
                Label labelCFMedico = null;
                for (MedicoDTO m : medici)
                    if (x.getCodiceFiscaleMedico().equals(m.getCodiceFiscale())) {
                        labelCFMedico = new Label(" Medico: " + m.getNome() + " " + m.getCognome());
                        labelCFMedico.setStyle("-fx-text-fill: #555;");
                    }
                refertoBox = new VBox(labelNomeReferto, labelDataReferto, labelCFMedico, labelPaziente);
            } else if (x.getNomeReferto().contains("Prelievo") || x.getNomeReferto().contains("Medicazione")) {
                for (InfermiereDTO y : infermieri) {
                    if (y.getCodiceFiscale().equals(x.getCodiceFiscaleInfermiere()))
                        infermiere = y;
                }
                Label labelInfermiere = new Label("Infermiere: " + infermiere.getNome() + " " + infermiere.getCognome());
                labelInfermiere.setStyle("-fx-text-fill: #555;");
                refertoBox = new VBox(labelNomeReferto, labelCodiceReferto, labelDataReferto, labelPaziente);
            }
            refertoBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
            refertoBox.setSpacing(5);
            refertoBox.prefWidthProperty().bind(refertiVBox.widthProperty());
            refertiVBox.getChildren().add(refertoBox);
            refertoBox.setOnMouseClicked(event -> apriPdf(x.getCodiceReferto()));
        }
    }

    private void apriPdf(String codiceReferto) {
        for (RefertoDTO x : referti) {
            if (x.getCodiceReferto().equals(codiceReferto)) {
                File file = new File("src/main/pdf/" + x.getNomeReferto());
                if (file.exists() && Desktop.isDesktopSupported()) {
                    try {
                        Desktop.getDesktop().open(file);
                    } catch (IOException e) {
                        System.err.println("Errore nell'aprire il PDF: " + e.getMessage());
                    }
                } else {
                    System.err.println("Il file PDF non esiste o il Desktop non è supportato.");
                }
                return;
            }
        }
    }

    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("Segreteria.fxml");
    }
}
