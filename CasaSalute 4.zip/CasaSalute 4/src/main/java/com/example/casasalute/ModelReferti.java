package com.example.casasalute;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ModelReferti {

    private static ModelReferti instance;
    private static final String FILE_PATH = "src/main/txt/referti.txt";
    public static final List<RefertoDTO> referti = new ArrayList<>();

    public static ModelReferti getInstance() {
        if (instance == null) {
            instance = new ModelReferti();
        }
        return instance;
    }

    ModelReferti() {
        try (BufferedReader br = new BufferedReader(new FileReader("src/main/txt/referti.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] dati = line.split("\t");
                if (dati.length == 10) {
                    RefertoDTO referto = new RefertoDTO(
                            // codice referto
                            dati[1], // nome referto
                            dati[2], // data referto
                            dati[3], // cf medico
                            dati[4], // cf medico sostituito
                            dati[5], // cs paziente
                            dati[6], // ambulatorio
                            dati[7], // regime referto
                            dati[8], // urgenza referto
                            dati[9] // tipo visita
                    );
                    referti.add(referto);
                } else if (dati.length == 6) {
                    RefertoDTO referto = new RefertoDTO(
                            // codice referto
                            dati[1], // nome referto
                            dati[2], // data referto
                            dati[3], // cf infermiere
                            dati[4], // cs paziente
                            dati[5] // esito referto
                    );
                    referti.add(referto);
                }
            }
        } catch (IOException e) {
            System.err.println("Nessun file referti trovato: " + e);
        }
    }

    public void aggiungiReferto(RefertoDTO referto) {
        referti.add(referto);
        aggiornaFile();
    }

    public static void aggiornaFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (RefertoDTO referto : referti) {
                writer.write(referto.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Errore durante l'aggiornamento del file: " + e.getMessage());
        }
    }

    public List<RefertoDTO> getAllReferti() {
        return referti;
    }

}
