package com.example.casasalute;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ModificaInfermiereController implements DataReceiver {

    @FXML private Label nomeInfermiere;
    @FXML private Label cfText;
    @FXML private Label nomeText;
    @FXML private Label cognomeText;
    @FXML private TextField emailText;
    @FXML private TextField passwordText;
    @FXML private Label erroreDati;
    @FXML private Label erroreTurni;
    @FXML private ChoiceBox<String> lun;
    @FXML private ChoiceBox<String> mar;
    @FXML private ChoiceBox<String> mer;
    @FXML private ChoiceBox<String> gio;
    @FXML private ChoiceBox<String> ven;
    private final List<InfermiereDTO> infermieri = ModelInfermieri.getInstance().getAllInfermieri();
    private InfermiereDTO infermiere;

    @Override
    public void setData(Object data) {
        if (data instanceof InfermiereDTO) {
            infermiere = (InfermiereDTO) data;
            setNomeInfermiere();
            compilaCampi();
            setTurni();
        }
    }

    private void setNomeInfermiere() {
        nomeInfermiere.setText(infermiere.getNome() + " " + infermiere.getCognome());
    }

    private void compilaCampi(){
        if (infermiere != null) {
            cfText.setText(infermiere.getCodiceFiscale());
            nomeText.setText(infermiere.getNome());
            cognomeText.setText(infermiere.getCognome());
            emailText.setText(infermiere.getEmail());
            passwordText.setText(infermiere.getPassword());
        }
    }

    private void setTurni(){
        List<TurnoDTO> turni = ModelTurni.getInstance().getTurniInfermiere(infermiere.getCodiceFiscale());
        for(TurnoDTO x : turni){
            switch (x.getGiorno()) {
                case "Lunedì":
                    lun.setValue(x.getTurno());
                    break;
                case "Martedì":
                    mar.setValue(x.getTurno());
                    break;
                case "Mercoledì":
                    mer.setValue(x.getTurno());
                    break;
                case "Giovedì":
                    gio.setValue(x.getTurno());
                    break;
                case "Venerdì":
                    ven.setValue(x.getTurno());
                    break;
            }
        }
    }

    @FXML
    private void modificaInfermiere() throws IOException {
        if (controlli()) {
            InfermiereDTO infermiereTrovato = infermieri.stream()
                    .filter(i -> i.getCodiceFiscale().equalsIgnoreCase(infermiere.getCodiceFiscale()))
                    .findFirst()
                    .orElse(null);

            if (infermiereTrovato != null) {
                infermiereTrovato.setCodiceFiscale(cfText.getText());
                infermiereTrovato.setNome(nomeText.getText());
                infermiereTrovato.setCognome(cognomeText.getText());
                infermiereTrovato.setEmail(emailText.getText());
                infermiereTrovato.setPassword(passwordText.getText());
                ModelInfermieri.aggiornaFile();
                HelloApplication pagina = new HelloApplication();
                pagina.changeScene("VisualizzaDatiInfermiere.fxml");
            } else {
                erroreDati.setText("Errore: Infermiere non trovato.");
            }
        }
    }

    private boolean controlli() {
        if (emailText.getText().isEmpty() || passwordText.getText().isEmpty()) {
            erroreDati.setText("Tutti i campi devono essere compilati!");
            return false;
        }
        if (!emailText.getText().matches("^[\\w.-]+@[a-zA-Z\\d.-]+\\.[a-zA-Z]{2,}$")) {
            erroreDati.setText("L'email non è valida. Assicurati che sia nel formato corretto.");
            return false;
        }
        return true;
    }


    @FXML
    private void modificaTurni() throws IOException {
        int giorniLiberi = 0;
        List<TurnoDTO> nuoviTurni = new ArrayList<>();
        if (lun.getValue().equals("-")) {
            giorniLiberi++;
            nuoviTurni.add(new TurnoDTO(infermiere.getCodiceFiscale(), "Lunedì", lun.getValue()));
        } else nuoviTurni.add(new TurnoDTO(infermiere.getCodiceFiscale(), "Lunedì", lun.getValue()));
        if (mar.getValue().equals("-")) {
            giorniLiberi++;
            nuoviTurni.add(new TurnoDTO(infermiere.getCodiceFiscale(), "Martedì", mar.getValue()));
        } else nuoviTurni.add(new TurnoDTO(infermiere.getCodiceFiscale(), "Martedì", mar.getValue()));
        if (mer.getValue().equals("-")) {
            giorniLiberi++;
            nuoviTurni.add(new TurnoDTO(infermiere.getCodiceFiscale(), "Mercoledì", mer.getValue()));
        } else nuoviTurni.add(new TurnoDTO(infermiere.getCodiceFiscale(), "Mercoledì", mer.getValue()));
        if (gio.getValue().equals("-")) {
            giorniLiberi++;
            nuoviTurni.add(new TurnoDTO(infermiere.getCodiceFiscale(), "Giovedì", gio.getValue()));
        } else nuoviTurni.add(new TurnoDTO(infermiere.getCodiceFiscale(), "Giovedì", gio.getValue()));
        if (ven.getValue().equals("-")) {
            giorniLiberi++;
            nuoviTurni.add(new TurnoDTO(infermiere.getCodiceFiscale(), "Venerdì", ven.getValue()));
        } else nuoviTurni.add(new TurnoDTO(infermiere.getCodiceFiscale(), "Venerdì", ven.getValue()));

        if (giorniLiberi > 1) {
            erroreTurni.setText("Puoi avere solo un giorno libero!");
        } else if (giorniLiberi == 0)
            erroreTurni.setText("Manca il giorno libero!");
        else {
            ModelTurni.getInstance().aggiornaTurniInfermiere(infermiere.getCodiceFiscale(), nuoviTurni);
            HelloApplication pagina = new HelloApplication();
            pagina.changeScene("VisualizzaDatiInfermiere.fxml");
        }
    }

    @FXML
    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("VisualizzaDatiInfermiere.fxml");
    }
}
