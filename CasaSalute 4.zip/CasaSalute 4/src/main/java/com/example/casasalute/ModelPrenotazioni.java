package com.example.casasalute;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ModelPrenotazioni {

    private static ModelPrenotazioni instance;
    private static final String FILE_PATH = "src/main/txt/prenotazioni.txt";
    private static final List<String[]> visite = new ArrayList<>();
    private static final List<String[]> prestazioni = new ArrayList<>();

    public static ModelPrenotazioni getInstance() {
        if (instance == null) {
            instance = new ModelPrenotazioni();
        }
        return instance;
    }

    ModelPrenotazioni() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] dati = line.split("\t");
                if (dati.length == 7) {
                    visite.add(dati);
                } else if (dati.length == 4) {
                    prestazioni.add(dati);
                }
            }
        } catch (IOException e) {
            System.err.println("Nessun file prenotazioni trovato: " + e);
        }
    }

    public void aggiungiVisita(String codiceMedico, String codicePaziente, String tipoV, String dataV, String oraV, String regimeV, String ambulatorioV) {
        String[] nuovaVisita = {codiceMedico, codicePaziente, tipoV, dataV, oraV, regimeV, ambulatorioV};
        visite.add(nuovaVisita);
        aggiornaFile();
    }

    public void aggiungiPrestazione(String tipoP, String codicePaziente, String dataP, String oraP) {
        String[] nuovaPrestazione = {tipoP, codicePaziente, dataP, oraP};
        prestazioni.add(nuovaPrestazione);
        aggiornaFile();
    }

    public static void rimuoviVisita(String codiceMedico, String codicePaziente, String dataV, String oraV) {
        Iterator<String[]> iterator = visite.iterator();
        boolean removed = false;
        while (iterator.hasNext()) {
            String[] prenotazione = iterator.next();
            if (prenotazione[0].equals(codiceMedico) && prenotazione[1].equals(codicePaziente)
                    && prenotazione[3].equals(dataV) && prenotazione[4].equals(oraV)) {
                iterator.remove();
                removed = true;
                break;
            }
        }
        if (!removed) {
            System.out.println("Nessuna prenotazione trovata da rimuovere.");
        } else {
            aggiornaFile();
        }
    }

    public static void rimuoviPrestazione(String tipoPrestazione, String codicePaziente, String dataV, String oraV) {
        Iterator<String[]> iterator = prestazioni.iterator();
        boolean removed = false;
        while (iterator.hasNext()) {
            String[] prenotazione = iterator.next();
            if (prenotazione[0].equals(tipoPrestazione) && prenotazione[1].equals(codicePaziente)
                    && prenotazione[2].equals(dataV) && prenotazione[3].equals(oraV)) {
                iterator.remove();
                removed = true;
                break;
            }
        }
        if (!removed) {
            System.out.println("Nessuna prenotazione trovata da rimuovere.");
        } else {
            aggiornaFile();
        }
    }

    private static void aggiornaFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (String[] visita : visite) {
                writer.write(String.join("\t", visita));
                writer.newLine();
            }
            for (String[] prestazione : prestazioni) {
                writer.write(String.join("\t", prestazione));
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Errore durante l'aggiornamento del file: " + e.getMessage());
        }
    }

    public List<String[]> getAllVisite() {
        return new ArrayList<>(visite);
    }

    public List<String[]> getAllPrestazioni() {
        return new ArrayList<>(prestazioni);
    }
}
