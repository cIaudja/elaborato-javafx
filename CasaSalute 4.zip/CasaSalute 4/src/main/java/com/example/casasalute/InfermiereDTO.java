package com.example.casasalute;

public class InfermiereDTO {
    private String codiceFiscale;
    private String nome;
    private String cognome;
    private String password;
    private String email;

    // Costruttore
    public InfermiereDTO(String codiceFiscale, String nome, String cognome, String email, String password) {
        this.codiceFiscale = codiceFiscale;
        this.nome = nome;
        this.cognome = cognome;
        this.email = email;
        this.password = password;
    }

    public String getCodiceFiscale() {return codiceFiscale;}
    public void setCodiceFiscale(String codiceFiscale) {
        this.codiceFiscale = codiceFiscale;
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }
    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return this.codiceFiscale + "\t" +
                this.nome + "\t" +
                this.cognome + "\t" +
                this.email + "\t" +
                this.password + "\t";
    }
}