package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.*;
import java.util.stream.Collectors;

public class ProfiloFiglioController implements Initializable, DataReceiver{

    @FXML private Label nomePaziente;
    @FXML private VBox resoconto;
    @FXML private Label titolo1;
    @FXML private Label titolo2;
    private PazienteDTO paziente;
    private PazienteDTO pazienteFiglio;
    private final List<RefertoDTO> referti = ModelReferti.getInstance().getAllReferti();
    private final List<RefertoDTO> refertiFiltrati = new ArrayList<>();
    @FXML
    private ChoiceBox<String> annoReferto;

    @Override
    public void setData(Object data) {
        if (data instanceof ArrayList<?> datiPassati) {
            paziente = (PazienteDTO) datiPassati.getFirst();
            setNomePaziente(paziente);
            pazienteFiglio = (PazienteDTO) datiPassati.getLast();
            setTitles(pazienteFiglio);
            creaHbox();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        //Menu a tendina degli anni
        Set<String> anniUnici = new TreeSet<>();
        for (RefertoDTO x : referti) {
            String data = x.getDataReferto(); // Formato gg-mm-aaaa
            String anno = data.split("-")[2]; // Estrai solo l'anno
            anniUnici.add(anno);
        }
        List<String> opzioniAnni = new ArrayList<>(anniUnici); //opzione iniziale
        opzioniAnni.addFirst("Filtra per anno");
        annoReferto.setItems(FXCollections.observableArrayList(opzioniAnni)); //popola choiche box
        annoReferto.setValue("Filtra per anno"); //imposta valore iniziale
    }

    private void setNomePaziente (PazienteDTO paziente){
        nomePaziente.setText(paziente.getNome() + " " + paziente.getCognome());
    }

    private void setTitles (PazienteDTO figlio){
        titolo1.setText("Gestione attività per " + figlio.getNome() + " " + figlio.getCognome());
        titolo2.setText("Resoconto di " + figlio.getNome() + " " + figlio.getCognome());
    }

    private void creaHbox() {
        // Filtra i referti per il paziente
        for (RefertoDTO x : referti) {
            if (x.getCodiceSanitarioPaziente().equals(pazienteFiglio.getCodiceSanitario())) {
                refertiFiltrati.add(x);
            }
        }
        mostraReferti(refertiFiltrati);
        // Listener per la selezione dell'anno nel ChoiceBox
        annoReferto.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && !newValue.equals("Filtra per anno")) {
                resoconto.getChildren().clear(); // Pulisce gli elementi esistenti nella VBox
                // Resetta i referti filtrati ogni volta che viene selezionato un nuovo anno
                List<RefertoDTO> refertiAnno = refertiFiltrati.stream()
                        .filter(referto -> referto.getDataReferto().endsWith(newValue))
                        .collect(Collectors.toList());
                mostraReferti(refertiAnno); // Mostra i referti filtrati per l'anno selezionato
            } else {
                // Se non è selezionato un anno specifico, mostra tutti i referti
                resoconto.getChildren().clear(); // Pulisce gli elementi esistenti nella VBox
                mostraReferti(refertiFiltrati);
            }
        });
    }

    private void mostraReferti(List<RefertoDTO> refertiFiltrati){
        for (RefertoDTO x : refertiFiltrati) {
            Label labelNomeReferto = new Label(x.getNomeReferto());
            labelNomeReferto.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");
            VBox refertoBox = getRefertoBox(x);
            refertoBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
            refertoBox.setSpacing(5);
            refertoBox.prefWidthProperty().bind(resoconto.widthProperty()); // Aggiunge il refertoBox alla VBox principale
            resoconto.getChildren().add(refertoBox);
            refertoBox.setOnMouseClicked(event -> apriPdf(x.getCodiceReferto()));
        }
    }

    private static VBox getRefertoBox(RefertoDTO x) {
        Label labelTipo = new Label();
        if (x.getNomeReferto().contains("Visita"))
            labelTipo = new Label(" Tipo prestazione: " + x.getTipoVisita());
        else if (x.getNomeReferto().contains("Prelievo"))
            labelTipo = new Label(" Tipo prestazione: Prelievo");
        else if (x.getNomeReferto().contains("Medicazione"))
            labelTipo = new Label(" Tipo prestazione: Medicazione");
        labelTipo.setStyle("-fx-text-fill: #555;");
        Label labelDataReferto = new Label(" Data: " + x.getDataReferto());
        labelDataReferto.setStyle("-fx-text-fill: #555;");
        Label labelUrgenza = new Label(" Urgenza: " + x.getUrgenzaReferto());
        labelUrgenza.setStyle("-fx-text-fill: #555;");
        Label labelRegime = new Label(" Regime: " + x.getRegimeReferto());
        labelRegime.setStyle("-fx-text-fill: #555;");
        return new VBox(labelTipo, labelDataReferto, labelUrgenza, labelRegime);
    }

    private void apriPdf(String codiceReferto) {
        String percorsoReferto = "";
        boolean trovato = false;
        for (RefertoDTO x: referti){
            if (x.getCodiceReferto().equals(codiceReferto)){
                percorsoReferto = "src/main/pdf/" + x.getNomeReferto();
                trovato = true;
            }
        }
        if (trovato && Desktop.isDesktopSupported()) {
            File file = new File(percorsoReferto);
            try {
                // Usa il Desktop per aprire il PDF
                Desktop.getDesktop().open(file);
            } catch (IOException e) {
                System.err.println("Errore nell'aprire il PDF: " + e.getMessage());
            }
        } else {
            System.err.println("Il file PDF non esiste o il Desktop non è supportato.");
        }
    }

    @FXML
    public void prenotaVisita() throws IOException{
        List<Object> dati = new ArrayList<>();
        dati.add(paziente);
        dati.add(pazienteFiglio);
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("PrenotaVisita.fxml", dati);
    }

    @FXML
    public void prenotaPrestazione() throws IOException{
        List<Object> dati = new ArrayList<>();
        dati.add(paziente);
        dati.add(pazienteFiglio);
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("PrenotaPrestazione.fxml", dati);
    }

    @FXML
    public void visualizzaPrenotazioni() throws IOException {
        List<Object> dati = new ArrayList<>();
        dati.add(paziente);
        dati.add(pazienteFiglio);
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("VisualizzaPrenotazioni.fxml", dati);
    }

    @FXML
    public void back() throws IOException{
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("NucleoFamiliare.fxml", paziente);
    }
}
