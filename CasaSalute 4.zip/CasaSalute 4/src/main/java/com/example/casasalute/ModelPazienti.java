package com.example.casasalute;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ModelPazienti {
    
    private static ModelPazienti instance;
    private static final String FILE_PATH = "src/main/txt/pazienti.txt";
    private static final List<PazienteDTO> pazienti = new ArrayList<>();

    public static ModelPazienti getInstance() {
        if (instance == null){
            instance = new ModelPazienti();
        }
        return instance;
    }

    ModelPazienti() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] dati = line.split("\t");
                if (dati.length == 10) {
                    PazienteDTO paziente = new PazienteDTO(
                            dati[1], // nome
                            dati[2], // cognome
                            dati[3], // data
                            dati[4], // luogo
                            dati[5], // email
                            dati[6], // password
                            dati[7], // emailTutore
                            dati[8], // medico curante
                            dati[9] // CS tutore
                    );
                    pazienti.add(paziente);
                }
            }
        } catch (IOException e) {
            System.err.println("Nessun file pazienti trovato: " + e);
        }
    }

    public static void aggiungiPaziente(PazienteDTO paziente) {
        pazienti.add(paziente);
        aggiornaFile();
    }

    public static void aggiornaFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (PazienteDTO paziente : pazienti) {
                writer.write(paziente.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Errore durante l'aggiornamento del file: " + e.getMessage());
        }
    }

    public List<PazienteDTO> getAllPazienti() {
        return pazienti;
    }

}
