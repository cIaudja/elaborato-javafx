package com.example.casasalute;

public interface DataReceiver {
    void setData(Object data);
}
