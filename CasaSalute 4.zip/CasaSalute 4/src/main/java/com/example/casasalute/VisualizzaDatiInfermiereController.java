package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class VisualizzaDatiInfermiereController implements Initializable {

    @FXML private TableView<InfermiereDTO> tabella;
    @FXML private TableColumn<InfermiereDTO, String> codiceFiscale;
    @FXML private TableColumn<InfermiereDTO, String> nome;
    @FXML private TableColumn<InfermiereDTO, String> cognome;
    @FXML private TableColumn<InfermiereDTO, String> email;
    @FXML private TableColumn<InfermiereDTO, String> password;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        codiceFiscale.setCellValueFactory(new PropertyValueFactory<>("codiceFiscale"));
        nome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        cognome.setCellValueFactory(new PropertyValueFactory<>("cognome"));
        email.setCellValueFactory(new PropertyValueFactory<>("email"));
        password.setCellValueFactory(new PropertyValueFactory<>("password"));
        ObservableList<InfermiereDTO> infermiereObservable = FXCollections.observableList(ModelInfermieri.getInstance().getAllInfermieri());
        tabella.setItems(infermiereObservable);
        tabella.setRowFactory(tv -> {
            TableRow<InfermiereDTO> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (!row.isEmpty() && event.getClickCount() == 1) { // Click singolo
                    InfermiereDTO selectedInfermiere = row.getItem();
                    try {
                        handleRowClick(selectedInfermiere);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            return row;
        });
    }

    private void handleRowClick(InfermiereDTO infermiere) throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("ModificaInfermiere.fxml", infermiere);
    }

    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("Segreteria.fxml");
    }

    @FXML
    public void creaInfermiere() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("CreaInfermiere.fxml");
    }
}




