package com.example.casasalute;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import java.io.IOException;
import java.util.List;

public class LoginController {

    @FXML private Label errore;
    @FXML private TextField email;
    @FXML private PasswordField password;
    private final List<PazienteDTO> pazienti = ModelPazienti.getInstance().getAllPazienti();
    private final List<MedicoDTO> medici = ModelMedici.getInstance().getAllMedici();
    private final List<InfermiereDTO> infermieri = ModelInfermieri.getInstance().getAllInfermieri();

    @FXML
    public void registrati() throws IOException{
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("Registrazione.fxml");
    }

    @FXML
    public void accedi() throws IOException {
        if (email.getText().isEmpty()) {
            email.requestFocus();
            errore.setText("Inserire l'email!");
            return;
        }
        if (password.getText().isEmpty()) {
            password.requestFocus();
            errore.setText("Inserire la password!");
            return;
        }
        HelloApplication pagina = new HelloApplication();
        if (email.getText().equalsIgnoreCase("segreteria@casaSalute.it") && password.getText().equals("Segreteria!"))
            pagina.changeScene("Segreteria.fxml");
        else {
            for (PazienteDTO x : pazienti)
                if (x.getEmail().equalsIgnoreCase(email.getText()) && x.getPassword().equals(password.getText()))
                    pagina.changeSceneWithData("ProfiloUser.fxml", x);
            for (MedicoDTO x : medici)
                if (x.getEmail().equalsIgnoreCase(email.getText()) && x.getPassword().equals(password.getText()))
                    pagina.changeSceneWithData("ProfiloMedico.fxml", x);
            for (InfermiereDTO x : infermieri)
                if (x.getEmail().equalsIgnoreCase(email.getText()) && x.getPassword().equals(password.getText()))
                    pagina.changeSceneWithData("ProfiloInfermiere.fxml", x);
            errore.setText("Username o password sono errati!");
        }
    }
}
