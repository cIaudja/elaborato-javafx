package com.example.casasalute;
import java.io.*;
import java.util.*;
import java.time.LocalDate;

public class ModelAssenze {

    private static ModelAssenze instance;
    private final Map<String, Set<LocalDate>> assenzeMedici = new HashMap<>();

    public static ModelAssenze getInstance() {
        if (instance == null){
            instance = new ModelAssenze();
        }
        return instance;
    }

    //Carica medici da file
    ModelAssenze() {
        try (BufferedReader br = new BufferedReader(new FileReader("src/main/txt/assenze.txt"))) {
            String line;

            while ((line = br.readLine()) != null) {

                String[] dati = line.split("\t"); // Split dei dati sulla base del separatore tabulazione
                if (dati.length > 1){
                    String codiceFiscale = dati[0];
                    Set<LocalDate> assenze = new HashSet<>();
                    for (int i = 1; i < dati.length; i++) {
                        assenze.add(LocalDate.parse(dati[i]));
                    }
                    assenzeMedici.put(codiceFiscale, assenze);
                }
            }
        } catch (IOException e) {
            System.out.println("File assenze non trovato: " + e);
        }
    }

    public void aggiungiAssenze(String codiceFiscale, Set<LocalDate> nuoveAssenze) {
        Set<LocalDate> assenzeEsistenti = assenzeMedici.getOrDefault(codiceFiscale, new HashSet<>());
        assenzeEsistenti.addAll(nuoveAssenze);
        assenzeMedici.put(codiceFiscale, assenzeEsistenti);
        aggiornaFile();
    }

    public void aggiornaFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/main/txt/assenze.txt"))) {
            for (Map.Entry<String, Set<LocalDate>> entry : assenzeMedici.entrySet()) {
                writer.write(entry.getKey() + "\t");
                for (LocalDate data : entry.getValue()) {
                    writer.write(data.toString() + "\t");
                }
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Errore durante l'aggiornamento del file: " + e.getMessage());
        }
    }

    public Set<LocalDate> getAllAssenze(String codiceFiscale) {
        return assenzeMedici.getOrDefault(codiceFiscale, new HashSet<>());
    }
}

