package com.example.casasalute;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ModelInfermieri {

    private static ModelInfermieri instance;
    private static final String FILE_PATH = "src/main/txt/infermieri.txt";
    private static final List<InfermiereDTO> infermieri = new ArrayList<>();

    public static ModelInfermieri getInstance() {
        if (instance == null){
            instance = new ModelInfermieri();
        }
        return instance;
    }

    ModelInfermieri() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] dati = line.split("\t");
                if (dati.length == 5) {
                    InfermiereDTO infermiere = new InfermiereDTO(
                            dati[0], // CF
                            dati[1], // nome
                            dati[2], // cognome
                            dati[3], // email
                            dati[4]  // password
                    );
                    infermieri.add(infermiere);
                }
            }
        } catch (IOException e) {
            System.err.println("Nessun file infermieri trovato: " + e);
        }
    }

    public void aggiungiInfermiere(InfermiereDTO nuovoInfermiere) {
        infermieri.add(nuovoInfermiere);
        aggiornaFile();
    }

    public static void aggiornaFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (InfermiereDTO infermiere : infermieri) {
                writer.write(infermiere.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Errore durante l'aggiornamento del file: " + e.getMessage());
        }
    }

    public List<InfermiereDTO> getAllInfermieri() {
        return infermieri;
    }

}
