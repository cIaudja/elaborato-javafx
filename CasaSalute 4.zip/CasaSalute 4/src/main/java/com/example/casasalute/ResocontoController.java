package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class ResocontoController implements Initializable, DataReceiver {

    @FXML private Label nome;
    @FXML private Label nomeAccesso;
    @FXML private VBox resoconto;
    @FXML private ChoiceBox<String> annoReferto;
    @FXML private Label titolo;
    private MedicoDTO medico;
    private InfermiereDTO infermiere;
    private InfermiereDTO infermiereReferto;
    private PazienteDTO paziente;
    private final List<RefertoDTO> referti = ModelReferti.getInstance().getAllReferti();
    private final List<InfermiereDTO> infermieri = ModelInfermieri.getInstance().getAllInfermieri();
    private final List<RefertoDTO> refertiFiltrati = new ArrayList<>();
    private boolean segreteria = false;


    @Override
    public void setData(Object data) {
        if (data instanceof ArrayList<?> datiPassati) {
            if (datiPassati.getFirst() instanceof MedicoDTO) {
                medico = (MedicoDTO) datiPassati.getFirst();
                setNomeMedico();
            }
            if (datiPassati.getFirst() instanceof InfermiereDTO) {
                infermiere = (InfermiereDTO) datiPassati.getFirst();
                setNomeInfermiere();
            }
            if (datiPassati.getFirst() instanceof String) {
                segreteria = true;
                setSegreteria();
            }
            paziente = (PazienteDTO) datiPassati.getLast();
            titolo.setText("Resoconto di " + paziente.getNome() + " " + paziente.getCognome());
            creaHbox();
        } else if (data instanceof PazienteDTO) {
            paziente = (PazienteDTO) data;
            setNomePaziente();
            creaHbox();
        }


    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        Set<String> anniUnici = new TreeSet<>();
        for (RefertoDTO x : referti) {
            String data = x.getDataReferto(); // Formato gg-mm-aaaa
            String anno = data.split("-")[2]; // Estrai solo l'anno
            anniUnici.add(anno);
        }
        List<String> opzioniAnni = new ArrayList<>(anniUnici); //opzione iniziale
        opzioniAnni.addFirst("Filtra per anno");
        annoReferto.setItems(FXCollections.observableArrayList(opzioniAnni)); //popola choice box
        annoReferto.setValue("Filtra per anno"); //imposta valore iniziale
    }

    public void setNomeMedico(){
        nome.setText(medico.getNome() + " " + medico.getCognome());
        nomeAccesso.setText("MEDICO");
    }

    public void setNomeInfermiere(){
        nome.setText(infermiere.getNome() + " " + infermiere.getCognome());
        nomeAccesso.setText("INFERMIERE");
    }

    public void setNomePaziente() {
        nome.setText(paziente.getNome() + " " + paziente.getCognome());
        nomeAccesso.setText("PAZIENTE");
    }

    public void setSegreteria() {
        nome.setText("");
        nomeAccesso.setText("SEGRETERIA");
    }

    private void creaHbox() {
        for (RefertoDTO x : referti) {
            if (x.getCodiceSanitarioPaziente().equals(paziente.getCodiceSanitario())) {
                refertiFiltrati.add(x);
            }
        }

        mostraReferti(refertiFiltrati);

        //listenter
        annoReferto.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && !newValue.equals("Filtra per anno")) {
                resoconto.getChildren().clear(); // Pulisce gli elementi esistenti nella VBox
                List<RefertoDTO> refertiAnno = refertiFiltrati.stream()// Resetta i referti filtrati ogni volta che viene selezionato un nuovo anno
                        .filter(referto -> referto.getDataReferto().endsWith(newValue))
                        .collect(Collectors.toList());
                mostraReferti(refertiAnno); // Mostra i referti filtrati per anno selezionato
            } else {
                // Se non è selezionato un anno specifico, mostra tutti i referti
                resoconto.getChildren().clear(); // Pulisce gli elementi esistenti nella VBox
                mostraReferti(refertiFiltrati);

            }
        });
    }

    private void mostraReferti(List<RefertoDTO> refertiFiltrati){
        VBox refertoBox = new VBox();
        for (RefertoDTO x : refertiFiltrati) {
            if (x.getNomeReferto().contains("Visita")) {
                Label labelNomeReferto = new Label(x.getNomeReferto());
                labelNomeReferto.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");
                Label labelTipo = new Label(" Tipo prestazione: " + x.getTipoVisita());
                labelTipo.setStyle("-fx-text-fill: #555;");
                Label labelDataReferto = new Label(" Data: " + x.getDataReferto());
                labelDataReferto.setStyle("-fx-text-fill: #555;");
                Label labelUrgenza = new Label(" Urgenza: " + x.getUrgenzaReferto());
                labelUrgenza.setStyle("-fx-text-fill: #555;");
                Label labelRegime = new Label(" Regime: " + x.getRegimeReferto());
                labelRegime.setStyle("-fx-text-fill: #555;");
                refertoBox = new VBox(labelNomeReferto, labelTipo, labelDataReferto, labelUrgenza, labelRegime);
                refertoBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
                refertoBox.setSpacing(5);
            } else if (x.getNomeReferto().contains("Prelievo") || x.getNomeReferto().contains("Medicazione")) {
                Label labelNomeReferto = new Label(x.getNomeReferto());
                labelNomeReferto.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");
                Label labelTipo;
                if (x.getNomeReferto().contains("Prelievo"))
                    labelTipo = new Label(" Tipo prestazione: Prelievo");
                else
                    labelTipo = new Label(" Tipo prestazione: Medicazione");
                labelTipo.setStyle("-fx-text-fill: #555;");
                Label labelDataReferto = new Label(" Data: " + x.getDataReferto());
                labelDataReferto.setStyle("-fx-text-fill: #555;");
                Label labelEsito = new Label(" Esito: " + x.getEsitoReferto());
                labelEsito.setStyle("-fx-text-fill: #555;");
                for (InfermiereDTO y : infermieri)
                    if (x.getCodiceFiscaleInfermiere().equals(y.getCodiceFiscale()))
                        infermiereReferto = y;
                Label labelPI = new Label(" Personale infermieristico: " + infermiereReferto.getNome() + " " + infermiereReferto.getCognome());
                labelPI.setStyle("-fx-text-fill: #555;");
                refertoBox = new VBox(labelNomeReferto, labelTipo, labelDataReferto, labelEsito, labelPI);
                refertoBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
                refertoBox.setSpacing(5);
            }
            refertoBox.prefWidthProperty().bind(resoconto.widthProperty());
            resoconto.getChildren().add(refertoBox);
            refertoBox.setOnMouseClicked(event -> apriPdf(x.getCodiceReferto()));
        }
    }

    // Metodo per aprire il PDF
    private void apriPdf(String codiceReferto) {
        String percorsoReferto = "";
        boolean trovato = false;
        for (RefertoDTO x: referti){
            if (x.getCodiceReferto().equals(codiceReferto)){
                percorsoReferto = "src/main/pdf/" + x.getNomeReferto();
                trovato = true;
            }
        }
        if (trovato && Desktop.isDesktopSupported()) {
            File file = new File(percorsoReferto);
            try {
                // Usa il Desktop per aprire il PDF
                Desktop.getDesktop().open(file);
            } catch (IOException e) {
                System.err.print("Errore nell'aprire il PDF: " + e.getMessage());
            }
        } else {
            System.err.print("Il file PDF non esiste o il Desktop non è supportato.");
        }
    }

    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        if (medico != null)
            pagina.changeSceneWithData("PazientiConvenzionati.fxml", medico);
        else if (infermiere != null)
            pagina.changeSceneWithData("VisualizzaDatiPazienteResoconto.fxml", infermiere);
        else if (segreteria)
            pagina.changeSceneWithData("VisualizzaDatiPazienteResoconto.fxml", "s");
        else
            pagina.changeSceneWithData("ProfiloUser.fxml", paziente);
    }

}




