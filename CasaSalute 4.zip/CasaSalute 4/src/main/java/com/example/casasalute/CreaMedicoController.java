package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class CreaMedicoController implements Initializable {
    @FXML private Label errore;
    @FXML private TextField codiceFiscaleText;
    @FXML private TextField nomeText;
    @FXML private TextField cognomeText;
    @FXML private TextField emailText;
    @FXML private PasswordField passwordText;
    @FXML private TextArea specialitaText;
    @FXML private ChoiceBox<String> sostituto1;
    @FXML private ChoiceBox<String> sostituto2;
    private final List<String> codiceMedici = new ArrayList<>();
    private final List<MedicoDTO> medici = ModelMedici.getInstance().getAllMedici();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        List<MedicoDTO> medici = ModelMedici.getInstance().getAllMedici();

        if (!medici.isEmpty()) {
            // Aggiungi tutti i medici alla lista per i sostituti
            for (MedicoDTO x : medici) {
                codiceMedici.add(x.getCodiceFiscale());
            }

            // Imposta gli elementi per il primo sostituto
            sostituto1.setItems(FXCollections.observableArrayList(codiceMedici));

            // Listener per aggiornare il secondo sostituto
            sostituto1.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
                if (newValue != null) {
                    // Filtra il secondo sostituto per evitare duplicati
                    List<String> opzioniFiltrate = new ArrayList<>(codiceMedici);
                    opzioniFiltrate.remove(newValue);
                    sostituto2.setItems(FXCollections.observableArrayList(opzioniFiltrate));
                } else {
                    // Ripristina tutte le opzioni se nulla è selezionato
                    sostituto2.setItems(FXCollections.observableArrayList(codiceMedici));
                }
            });
        }
    }

    @FXML
    private void creaMedico() throws IOException {
        HelloApplication pagina = new HelloApplication();
        String cf = codiceFiscaleText.getText();
        String nome = nomeText.getText();
        String cognome = cognomeText.getText();
        String email = emailText.getText();
        String password = passwordText.getText();
        String specialita = specialitaText.getText();
        String valoreSostituto1 = sostituto1.getValue();
        String valoreSostituto2 = sostituto2.getValue();
        String sostituto1Finale = valoreSostituto1 == null ? "null" : valoreSostituto1;
        String sostituto2Finale = valoreSostituto2 == null ? "null" : valoreSostituto2;

        if (controlli()) {
            MedicoDTO nuovoMedico = new MedicoDTO(cf, nome, cognome, email, password, specialita, sostituto1Finale, sostituto2Finale);
            for (MedicoDTO x : medici)
                if (x.getCodiceFiscale().equals(nuovoMedico.getCodiceFiscale())) {
                    errore.setText("Questo medico esiste già!");
                    return;
                }
            ModelMedici.aggiungiMedico(nuovoMedico);
            pagina.changeScene("VisualizzaDatiMedico.fxml");
        }
    }

    private boolean controlli(){
        if (nomeText.getText().isEmpty() || cognomeText.getText().isEmpty() || codiceFiscaleText.getText().isEmpty() || specialitaText.getText().isEmpty() || emailText.getText().isEmpty() || passwordText.getText().isEmpty() || sostituto1.getValue() == null || sostituto2.getValue().equals("null")) {
            errore.setText("Tutti i campi devono essere compilati!");
            return false;
        }
        if (!emailText.getText().matches("^[\\w.-]+@[a-zA-Z\\d.-]+\\.[a-zA-Z]{2,}$")) {
            errore.setText("L'email non è valida. Assicurati che sia nel formato corretto.");
            return false;
        }
        return validaCodiceFiscale();
    }

    private boolean validaCodiceFiscale() {
        String cf = codiceFiscaleText.getText().toUpperCase();
        if (!cf.matches("^[A-Z]{6}\\d{2}[A-EHLMPRST]\\d{2}[A-Z]\\d{3}[A-Z]$")) {
            errore.setText("Il codice fiscale non è valido. Controlla che sia nel formato corretto.");
            return false;
        }
        char mese = cf.charAt(8);
        if ("ABCDEHLMPRST".indexOf(mese) == -1) {
            errore.setText("Il mese di nascita nel codice fiscale non è valido.");
            return false;
        }
        return true;
    }

    @FXML
    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("VisualizzaDatiMedico.fxml");
    }
}