package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class VisualizzaDatiMedicoController implements Initializable {

    @FXML private TableView<MedicoDTO> tabella;
    @FXML private TableColumn<MedicoDTO, String> codiceFiscale;
    @FXML private TableColumn<MedicoDTO, String> nome;
    @FXML private TableColumn<MedicoDTO, String> cognome;
    @FXML private TableColumn<MedicoDTO, String> email;
    @FXML private TableColumn<MedicoDTO, String> password;
    @FXML private TableColumn<MedicoDTO, String> specialita;
    @FXML private TableColumn<MedicoDTO, String> sostituto1;
    @FXML private TableColumn<MedicoDTO, String> sostituto2;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        codiceFiscale.setCellValueFactory(new PropertyValueFactory<>("codiceFiscale"));
        nome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        cognome.setCellValueFactory(new PropertyValueFactory<>("cognome"));
        email.setCellValueFactory(new PropertyValueFactory<>("email"));
        password.setCellValueFactory(new PropertyValueFactory<>("password"));
        specialita.setCellValueFactory(new PropertyValueFactory<>("specialita"));
        sostituto1.setCellValueFactory(new PropertyValueFactory<>("sostituto1"));
        sostituto2.setCellValueFactory(new PropertyValueFactory<>("sostituto2"));

        ObservableList<MedicoDTO> mediciObservable = FXCollections.observableList(ModelMedici.getInstance().getAllMedici());
        tabella.setItems(mediciObservable);

        tabella.setRowFactory(tv -> {
            TableRow<MedicoDTO> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (!row.isEmpty() && event.getClickCount() == 1) { // Click singolo
                    MedicoDTO selectedMedico = row.getItem();
                    try {
                        handleRowClick(selectedMedico);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            return row;
        });

    }

    private void handleRowClick(MedicoDTO medico) throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("ModificaMedico.fxml", medico);
    }

    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("Segreteria.fxml");
    }

    @FXML
    public void creaMedico() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("CreaMedico.fxml");
    }


}




