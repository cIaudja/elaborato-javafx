package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ProfiloInfermiereController implements DataReceiver {

    @FXML private Label nomeInfermiere;
    @FXML private TableView<TurnoDTO> turni;
    @FXML private TableColumn<TurnoDTO, String> giorno;
    @FXML private TableColumn<TurnoDTO, String> turno;
    @FXML private VBox prestazioniOggi;
    private InfermiereDTO infermiere;
    private final List<String[]> prenotazioni = ModelPrenotazioni.getInstance().getAllPrestazioni();
    private final List<PazienteDTO> pazienti = ModelPazienti.getInstance().getAllPazienti();

    @Override
    public void setData(Object data) {
        if (data instanceof InfermiereDTO) {
            infermiere = (InfermiereDTO) data;
            setNomeInfermiere();
            popolaTabella();
            creaVBoxOggi();
        }
    }
        private void setNomeInfermiere() {
        nomeInfermiere.setText(infermiere.getNome() + " " + infermiere.getCognome());
    }

    private void popolaTabella() {
        List<TurnoDTO> turniInfermiere = ModelTurni.getInstance().getTurniInfermiere(infermiere.getCodiceFiscale());
        giorno.setCellValueFactory(new PropertyValueFactory<>("giorno"));
        turno.setCellValueFactory(new PropertyValueFactory<>("turno"));
        giorno.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item);
                    setStyle("-fx-alignment: CENTER;");
                }
            }
        });
        turno.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item);
                    setStyle("-fx-alignment: CENTER;");
                }
            }
        });
        giorno.setPrefWidth(147);
        turno.setPrefWidth(150);
        turni.setFixedCellSize(53);
        turni.setItems(FXCollections.observableArrayList(turniInfermiere));
    }

    public void creaVBoxOggi() {
        prestazioniOggi.getChildren().clear(); // Pulisce gli elementi esistenti nella VBox
        List<String[]> prenotazioniFiltrate = new ArrayList<>();
        List<TurnoDTO> turniInfermiere = ModelTurni.getInstance().getTurniInfermiere(infermiere.getCodiceFiscale());
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        DateTimeFormatter formatterGiorno = DateTimeFormatter.ofPattern("EEEE", Locale.ITALIAN); // Formatter per il giorno in italiano
        for (String[] x : prenotazioni) {
            if (x[0].equals("Prelievo") || x[0].equals("Medicazione")) {
                LocalDate oggi = LocalDate.now(); // Ottieni la data di oggi
                LocalDate dataPrenotazione = LocalDate.parse(x[2], dateFormatter);
                if (dataPrenotazione.equals(oggi)) {  // Controlla se la prenotazione è di oggi
                    for (TurnoDTO y : turniInfermiere) {
                        if (((x[0].equals("Prelievo") && y.getTurno().contains("Prelievi")) || (x[0].equals("Medicazione") && y.getTurno().contains("Medicazioni")))) {
                            prenotazioniFiltrate.add(x);
                        }
                    }
                }
            }
        }
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm"); // Ordinamento per data e ora
        prenotazioniFiltrate.sort((a, b) -> {
            LocalDate dataA = LocalDate.parse(a[2], dateFormatter);
            LocalDate dataB = LocalDate.parse(b[2], dateFormatter);
            if (!dataA.equals(dataB)) {
                return dataA.compareTo(dataB); // Ordine crescente per data
            } else {
                LocalTime oraA = LocalTime.parse(a[3], timeFormatter);
                LocalTime oraB = LocalTime.parse(b[3], timeFormatter);
                return oraB.compareTo(oraA); // Ordine decrescente per ora
            }
        });
        for (String[] x : prenotazioniFiltrate) { // Creazione delle VBox per ogni prenotazione
            PazienteDTO paziente = null;
            for (PazienteDTO y : pazienti) {
                if (y.getCodiceSanitario().equals(x[1])) {
                    paziente = y;
                    break;
                }
            }
            if (paziente != null) {
                HBox prenBox = getPrenBox(x, paziente);
                prenBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ccc; -fx-border-radius: 5; -fx-background-radius: 5;");
                prenBox.setSpacing(20);
                prenBox.prefWidthProperty().bind(prestazioniOggi.widthProperty());
                prestazioniOggi.getChildren().add(prenBox);
                prenBox.setOnMouseClicked(event -> {
                    try {
                        creaPrestazione(x);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
            }
        }
    }
        private static HBox getPrenBox(String[] x, PazienteDTO paziente) {
        Label labelNomePaziente = new Label(paziente.getNome() + " " + paziente.getCognome());
        labelNomePaziente.setStyle("-fx-font-family: Arial; -fx-font-size: 14px; -fx-font-weight: bold;");
        Label labelTipoPrenotazione = new Label(x[0]); // Direttamente dal tipo di prenotazione
        labelTipoPrenotazione.setStyle("-fx-text-fill: #555;");
        Label labelDataPrenotazione = new Label(" Data: " + x[2]);
        labelDataPrenotazione.setStyle("-fx-text-fill: #555;");
        Label labelOraPrenotazione = new Label(" Ora: " + x[3]);
        labelOraPrenotazione.setStyle("-fx-text-fill: #555;");
        return new HBox(labelNomePaziente, labelTipoPrenotazione, labelDataPrenotazione, labelOraPrenotazione);
    }
        private void creaPrestazione(String [] datiPrenotazione) throws IOException {
        List<Object> dati = new ArrayList<>();
        dati.add(infermiere);
        dati.add(datiPrenotazione[0]); //tipo di prestazione
        dati.add(datiPrenotazione[1]); //CS paziente
        dati.add(datiPrenotazione[2]); //data prestazione
        dati.add(datiPrenotazione[3]); //ora prestazione
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("CreaPrestazione.fxml", dati);
    }

    @FXML
    public void storicoPrestazioni() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("StoricoReferti.fxml", infermiere);
    }

    @FXML
    public void datiPazientiRes() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("VisualizzaDatiPazienteResoconto.fxml", infermiere);
    }

    @FXML
    public void logOut() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("Login.fxml");
    }
}
