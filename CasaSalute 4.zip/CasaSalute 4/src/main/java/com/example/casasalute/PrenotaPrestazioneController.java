package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.util.Callback;
import javafx.util.StringConverter;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class PrenotaPrestazioneController implements Initializable, DataReceiver {

    @FXML private ChoiceBox<String>  tipoP;
    @FXML private DatePicker dataP;
    @FXML private ChoiceBox<String> oraP;
    @FXML private Label nomePaziente;
    @FXML private Label titolo;
    @FXML private Label labelTipo;
    @FXML private Label labelOra;
    @FXML private Button bottonePrenotazione;
    private PazienteDTO paziente;
    private PazienteDTO pazienteFiglio;
    private LocalDate dataSelezionata;

    public void setData(Object data) {
        if (data instanceof PazienteDTO) {
            paziente = (PazienteDTO) data;
            setNomePaziente(paziente);
        } else if (data instanceof ArrayList<?> datiPassati) {
            paziente = (PazienteDTO) datiPassati.getFirst();
            setNomePaziente(paziente);
            pazienteFiglio = (PazienteDTO) datiPassati.getLast();
            titolo.setText("Prenota prestazione di " + pazienteFiglio.getNome() + " " + pazienteFiglio.getCognome());
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        labelTipo.setVisible(false);
        tipoP.setVisible(false);
        labelOra.setVisible(false);
        oraP.setVisible(false);
        bottonePrenotazione.setVisible(false);
        dataP.setShowWeekNumbers(false);
        dataP.setConverter(new StringConverter<>() {
            private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

            @Override
            public String toString(LocalDate date) {
                return (date != null) ? dateFormatter.format(date) : "";
            }

            @Override
            public LocalDate fromString(String string) {
                return (string != null && !string.isEmpty()) ? LocalDate.parse(string, dateFormatter) : null;
            }
        });

        dataP.setDayCellFactory(getDayCellFactory());

        // Listener sulla data selezionata
        dataP.setOnAction(event -> {
            dataSelezionata = dataP.getValue();
            compilaCampi();
        });

        // Listener per aggiornare gli orari disponibili in base al tipo di prestazione selezionato
        tipoP.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (dataSelezionata != null) {
                compilaCampi();
            }
        });
    }

    private void setNomePaziente(PazienteDTO paziente){
        nomePaziente.setText(paziente.getNome() + " " + paziente.getCognome());
    }
    private Callback<DatePicker, DateCell> getDayCellFactory() {
        return picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                if (empty || date == null) {
                    setDisable(true);
                    return;
                }
                LocalDate oggi = LocalDate.now();

                // Disabilita i giorni passati
                if (date.isBefore(oggi)) {
                    setDisable(true);
                    setStyle("-fx-background-color: #d3d3d3;"); // Opzionale: colore grigio per i giorni passati
                    return;
                }

                // Disabilita sabato e domenica
                if (date.getDayOfWeek().getValue() == 6 || date.getDayOfWeek().getValue() == 7) {
                    setDisable(true);
                    setStyle("-fx-background-color: #d3d3d3;"); // Opzionale: colore grigio per sabato e domenica
                }
            }
        };
    }

    private void compilaCampi() {
        labelTipo.setVisible(true);
        tipoP.setVisible(true);
        labelOra.setVisible(true);
        oraP.setVisible(true);
        bottonePrenotazione.setVisible(true);

        if (dataSelezionata == null || tipoP.getValue() == null) return;
        String tipoSelezionato = tipoP.getValue();

        List<String> orariOccupati = getOrariOccupati(tipoSelezionato, dataSelezionata);
        ObservableList<String> orariDisponibili = FXCollections.observableArrayList();
        LocalTime oraCorrente = LocalTime.now();

        for (int ora = 8; ora < 12; ora++) {
            LocalTime slot1 = LocalTime.of(ora, 0);
            LocalTime slot2 = LocalTime.of(ora, 30);
            if (!dataSelezionata.isEqual(LocalDate.now()) || slot1.isAfter(oraCorrente)) {
                orariDisponibili.add(slot1.format(DateTimeFormatter.ofPattern("HH:mm")));
            }
            if (!dataSelezionata.isEqual(LocalDate.now()) || slot2.isAfter(oraCorrente)) {
                orariDisponibili.add(slot2.format(DateTimeFormatter.ofPattern("HH:mm")));
            }
        }

        for (int ora = 14; ora < 18; ora++) {
            LocalTime slot1 = LocalTime.of(ora, 0);
            LocalTime slot2 = LocalTime.of(ora, 30);
            if (!dataSelezionata.isEqual(LocalDate.now()) || slot1.isAfter(oraCorrente)) {
                orariDisponibili.add(slot1.format(DateTimeFormatter.ofPattern("HH:mm")));
            }
            if (!dataSelezionata.isEqual(LocalDate.now()) || slot2.isAfter(oraCorrente)) {
                orariDisponibili.add(slot2.format(DateTimeFormatter.ofPattern("HH:mm")));
            }
        }
        orariDisponibili.removeAll(orariOccupati);
        oraP.setItems(orariDisponibili);
    }


    private List<String> getOrariOccupati(String tipoPrestazione, LocalDate data) {
        List<String> orariOccupati = new ArrayList<>();
        List<String[]> prenotazioni = ModelPrenotazioni.getInstance().getAllPrestazioni();

        for (String[] prenotazione : prenotazioni) {
            String tipoP = prenotazione[0];
            LocalDate dataP = LocalDate.parse(prenotazione[2], DateTimeFormatter.ofPattern("dd-MM-yyyy"));
            if (tipoP.equals(tipoPrestazione) && dataP.equals(data)) {
                orariOccupati.add(prenotazione[3]); // Aggiungi l'orario occupato
            }
        }
        return orariOccupati;
    }

    @FXML
    public void confermaP() throws IOException {
        if(oraP.getValue() != null) {
            ModelPrenotazioni prestazione = ModelPrenotazioni.getInstance();
            String pz;
            List<Object> dati = new ArrayList<>();
            if (pazienteFiglio != null) {
                pz = pazienteFiglio.getCodiceSanitario();
                dati.add(paziente);
                dati.add(pazienteFiglio);
            } else
                pz = paziente.getCodiceSanitario();
            prestazione.aggiungiPrestazione(tipoP.getValue(), pz, dataSelezionata.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")), oraP.getValue());

            HelloApplication pagina = new HelloApplication();
            if (pazienteFiglio != null)
                pagina.changeSceneWithData("VisualizzaPrenotazioni.fxml", dati);
            else
                pagina.changeSceneWithData("VisualizzaPrenotazioni.fxml", paziente);
        }
    }

    @FXML
    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        if (pazienteFiglio != null) {
            List<Object> dati = new ArrayList<>();
            dati.add(paziente);
            dati.add(pazienteFiglio);
            pagina.changeSceneWithData("ProfiloFiglio.fxml", dati);
        }
        else
            pagina.changeSceneWithData("ProfiloUser.fxml", paziente);
    }
}
