package com.example.casasalute;

import javafx.scene.control.*;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CreaVisitaController implements DataReceiver {

    @FXML private Label pazienteV;
    @FXML private Label tipoV;
    @FXML private Label ambulatorioV;
    @FXML private Label dataV;
    @FXML private Label oraV;
    @FXML private Label regimeV;
    @FXML private ChoiceBox<String> urgenzaV;
    @FXML private TextArea sintomiV;
    @FXML private TextArea diagnosiV;
    @FXML private TextArea terapiaV;
    @FXML private TextField noteV;
    @FXML private Label nomeMedico;
    @FXML private Label errore;
    private final List<PazienteDTO> pazienti = ModelPazienti.getInstance().getAllPazienti();
    private final List<MedicoDTO> medici = ModelMedici.getInstance().getAllMedici();
    private MedicoDTO medico;
    private MedicoDTO medicoSostituito;
    private PazienteDTO paziente;

    @Override
    public void setData(Object data) {
        if (data instanceof ArrayList<?> datiPassati){
            medico = (MedicoDTO) datiPassati.getFirst();
            nomeMedico.setText(medico.getNome() + " " + medico.getCognome());
            for (PazienteDTO x: pazienti)
                if (x.getCodiceSanitario().equals(datiPassati.get(1))) {
                    pazienteV.setText(x.getNome() + " " + x.getCognome());
                    paziente = x;
                }
            String dataString = (String) datiPassati.get(3);
            dataV.setText(dataString);
            if (datiPassati.get(2).equals("Pediatrica")) {
                tipoV.setText("Visita Pediatrica");
                ambulatorioV.setText("Pediatrico");
            } else {
                tipoV.setText("Visita Medica");
                ambulatorioV.setText((String) datiPassati.get(6));
            }
            oraV.setText((String) datiPassati.get(4));
            regimeV.setText((String) datiPassati.get(5));
            if (!regimeV.getText().equals("Medico curante")){
                for (MedicoDTO x : medici)
                    if (x.getCodiceFiscale().equals(paziente.getMedico()))
                        medicoSostituito = x;
            }
        }
    }

    @FXML
    public void salvaV() {
        if (controllo()) {
            try {
                File pdfFile = creaPDF();
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(pdfFile);
                }

                RefertoDTO nuovaVisita = getNuovaVisita();
                ModelReferti.getInstance().aggiungiReferto(nuovaVisita);
                ModelPrenotazioni.rimuoviVisita(medico.getCodiceFiscale(), paziente.getCodiceSanitario(), dataV.getText(), oraV.getText());

                String corpo = getCorpo(nuovaVisita);
                MailDTO nuovaMail = getMailDTO(nuovaVisita, corpo);
                ModelMail.getInstance().aggiungiMail(nuovaMail);

                HelloApplication pagina = new HelloApplication();
                pagina.changeSceneWithData("StoricoReferti.fxml", medico);
            } catch (Exception e) {
                System.err.println("Errore, Si è verificato un errore durante la generazione del PDF:" + e);
            }
        }
    }

        private String getCorpo(RefertoDTO nuovaVisita) {
        String corpo;
        if (!paziente.getCSTutore().equals("null")) {
            corpo = "La informiamo che per il paziente nato il " + paziente.getData() +
                    " del suo nucleo familiare, è disponibile il referto " + nuovaVisita.getCodiceReferto() +
                    " della visita medica accedendo al portale.";
        } else {
            corpo = "La informiamo che per il paziente nato il " + paziente.getData() +
                    " è disponibile il referto " + nuovaVisita.getCodiceReferto() +
                    " della visita medica accedendo al portale.";
        }
        return corpo;
    }
        private MailDTO getMailDTO(RefertoDTO nuovaVisita, String corpo) {
        String destinatario = null;
        String tutore = "null";
        if (tipoV.getText().contains("Pediatrica")) {
            tutore = paziente.getEmailTutore();
        } else if (paziente.getEmailTutore().equals("null")) {
            destinatario = paziente.getEmail();
            tutore = paziente.getEmailTutore();
        } else {
            destinatario = paziente.getEmail();
        }
        return new MailDTO(nuovaVisita.getCodiceReferto(), destinatario, tutore, corpo);
    }
        private RefertoDTO getNuovaVisita() {
        String nomeFile = "";
        if (tipoV.getText().contains("Medica"))
         nomeFile = "VisitaMedica_" + dataV.getText() + ".pdf";
        else if (tipoV.getText().contains("Pediatrica"))
            nomeFile = "VisitaPediatrica_" +  dataV.getText() + ".pdf";
        String medicoSostituitoCF = null;
        if (medicoSostituito != null)
            medicoSostituitoCF = medicoSostituito.getCodiceFiscale();

        return new RefertoDTO(nomeFile,  dataV.getText(), medico.getCodiceFiscale(), medicoSostituitoCF, paziente.getCodiceSanitario(), ambulatorioV.getText(), regimeV.getText(), urgenzaV.getValue(), tipoV.getText());
    }
        private boolean controllo() {
        if (pazienteV.getText().isEmpty() || ambulatorioV.getText().isEmpty() || dataV.getText().isEmpty() || oraV.getText().isEmpty() || regimeV.getText().isEmpty() || urgenzaV.getValue() == null || sintomiV.getText().isEmpty() || diagnosiV.getText().isEmpty() || terapiaV.getText().isEmpty()) {
            errore.setText("Tutti i campi devono essere compilati (eccetto note aggiuntive)");
            return false;
        }
        return true;
    }

    private File creaPDF() throws IOException {
        PDDocument document = new PDDocument();
        PDPage page = new PDPage();
        document.addPage(page);

        try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 14);

            // Inserimento logo
            try {
                PDImageXObject logo = PDImageXObject.createFromFile("src/main/resources/img/logo_colorato.png", document);
                contentStream.drawImage(logo, 50, 720, 50, 50); // Posizione e dimensioni
            } catch (IOException e) {
                System.err.println("Errore nel caricamento del logo: " + e.getMessage());
            }

            // Titolo del documento
            contentStream.beginText();
            contentStream.newLineAtOffset(200, 750);
            contentStream.showText("Casa Salute - Report Visita");
            contentStream.endText();

            // Sezione Dati Paziente
            contentStream.beginText();
            contentStream.setFont(PDType1Font.HELVETICA, 12);
            contentStream.newLineAtOffset(50, 680);
            contentStream.showText("Nome e Cognome: " + pazienteV.getText());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Codice Sanitario: " + paziente.getCodiceSanitario());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Data di Nascita: " + paziente.getData());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Luogo di Nascita: " + paziente.getLuogo());
            contentStream.newLineAtOffset(0, -20);

            // Email del tutore se il paziente è minorenne
            if (!paziente.getCSTutore().equals("null")) {
                contentStream.showText("Email Tutore: " + paziente.getEmailTutore());
                contentStream.newLineAtOffset(0, -30);
            } else {
                if (!paziente.getEmailTutore().equals("null")) {
                    contentStream.showText("Email Paziente: " + paziente.getEmail());
                    contentStream.newLineAtOffset(0, -30);
                    contentStream.showText("Email Tutore: " + paziente.getEmailTutore());
                    contentStream.newLineAtOffset(0, -30);
                }
                else {
                    contentStream.showText("Email Paziente: " + paziente.getEmail());
                    contentStream.newLineAtOffset(0, -30);
                }
            }
            contentStream.endText();

            // Linea divisoria prima della sezione sintomi e diagnosi
            contentStream.moveTo(50, 540);
            contentStream.lineTo(550, 540);
            contentStream.stroke();

            // Sezione Dettagli Visita
            contentStream.beginText();
            contentStream.newLineAtOffset(50, 520);
            contentStream.showText("Tipo Visita: " + tipoV.getText());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Ambulatorio: " + ambulatorioV.getText());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Data: " + dataV.getText());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Ora: " + oraV.getText());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Urgenza: " + urgenzaV.getValue());
            contentStream.newLineAtOffset(0, -30); // Spazio prima della linea divisoria successiva
            contentStream.endText();

            // Linea divisoria prima della sezione sintomi e diagnosi
            contentStream.moveTo(50, 410);
            contentStream.lineTo(550, 410);
            contentStream.stroke();

            // Sezione Diagnosi e Sintomi
            contentStream.beginText();
            contentStream.newLineAtOffset(50, 390);
            contentStream.showText("Sintomi: " + sintomiV.getText());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Diagnosi: " + diagnosiV.getText());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Terapia: " + terapiaV.getText());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Note Aggiuntive: " + noteV.getText());
            contentStream.newLineAtOffset(0, -30); // Spazio prima della sezione medico
            contentStream.endText();

            // Sezione Medico e sostituzione
            contentStream.beginText();
            contentStream.newLineAtOffset(50, 300);
            contentStream.showText("Medico: " + medico.getNome() + " " + medico.getCognome());
            if (regimeV.getText().equals("Medico Sostitutivo")) {
                contentStream.newLineAtOffset(0, -20);
                contentStream.showText("Medico Sostituito: " + medicoSostituito.getNome() + " " + medicoSostituito.getCognome());
            }
            contentStream.endText();
        }

        // Creazione del nome del file basato sul tipo di visita
        String nomeFile = tipoV.getText().contains("Medica") ? "VisitaMedica_" + dataV.getText() + ".pdf" :
                tipoV.getText().contains("Pediatrica") ? "VisitaPediatrica_" + dataV.getText() + ".pdf" :
                        "Visita_" + dataV.getText() + ".pdf";

        String path = "src/main/pdf/" + nomeFile;
        File outputFile = new File(path);
        document.save(outputFile);
        document.close();
        return outputFile;
    }



    @FXML
    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("RefertiPrenotazioni.fxml", medico);
    }
}
