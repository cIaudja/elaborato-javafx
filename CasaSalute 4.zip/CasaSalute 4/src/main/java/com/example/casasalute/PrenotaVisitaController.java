package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.DatePicker;
import javafx.scene.control.*;
import javafx.util.Callback;
import javafx.util.StringConverter;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class PrenotaVisitaController implements Initializable, DataReceiver {

    @FXML private ChoiceBox<String> medicoV;
    @FXML private Label tipoV;
    @FXML private DatePicker dataV;
    @FXML private ChoiceBox<String> oraV;
    @FXML private Label regimeV;
    @FXML private Label nomePaziente;
    @FXML private Label titolo;
    @FXML private Label labelMedico;
    @FXML private Label labelTipo;
    @FXML private Label labelOra;
    @FXML private Label labelRegime;
    @FXML private Button bottonePrenotazione;
    private PazienteDTO paziente;
    private PazienteDTO pazienteFiglio;
    private MedicoDTO medicoCurante;
    private MedicoDTO medicoSostituto1;
    private MedicoDTO medicoSostituto2;
    private LocalDate dataSelezionata;
    private Set<LocalDate> assenze1 = new HashSet<>();
    private Set<LocalDate> assenze2 = new HashSet<>();
    private Set<LocalDate> assenze3 = new HashSet<>();
    private final List<MedicoDTO> medici = ModelMedici.getInstance().getAllMedici();
    private final List<String[]> prenotazioni = ModelPrenotazioni.getInstance().getAllVisite();
    private final ObservableList<String> mediciDisponibili = FXCollections.observableArrayList();
    private final List<String> ambulatori = Arrays.asList("Ambulatorio 1", "Ambulatorio 2", "Ambulatorio 3");


    public void setData(Object data) {
        if (data instanceof PazienteDTO) {
            paziente = (PazienteDTO) data;
            setNomePaziente(paziente);
            for (MedicoDTO x: medici){
                if (paziente.getMedico().equals(x.getCodiceFiscale()))
                    medicoCurante = x;
            }
        } else if (data instanceof ArrayList<?> datiPassati) {
            paziente = (PazienteDTO) datiPassati.getFirst();
            setNomePaziente(paziente);
            pazienteFiglio = (PazienteDTO) datiPassati.getLast();
            titolo.setText("Prenota visita di " + pazienteFiglio.getNome() + " " + pazienteFiglio.getCognome());
            for (MedicoDTO x: medici){
                if (pazienteFiglio.getMedico().equals(x.getCodiceFiscale()))
                    medicoCurante = x;
            }
        }

        assenze1 = ModelAssenze.getInstance().getAllAssenze(medicoCurante.getCodiceFiscale());
        for (MedicoDTO x : medici) {
            if (x.getCodiceFiscale().equals(medicoCurante.getSostituto1())) {
                medicoSostituto1 = x;
                assenze2 = ModelAssenze.getInstance().getAllAssenze(x.getCodiceFiscale());
            }
            if (x.getCodiceFiscale().equals(medicoCurante.getSostituto2())) {
                medicoSostituto2 = x;
                assenze3 = ModelAssenze.getInstance().getAllAssenze(x.getCodiceFiscale());
            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        labelMedico.setVisible(false);
        medicoV.setVisible(false);
        labelTipo.setVisible(false);
        tipoV.setVisible(false);
        labelOra.setVisible(false);
        oraV.setVisible(false);
        labelRegime.setVisible(false);
        regimeV.setVisible(false);
        bottonePrenotazione.setVisible(false);
        dataV.setShowWeekNumbers(false);
        dataV.setConverter(new StringConverter<>() {
            private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

            @Override
            public String toString(LocalDate date) {
                return (date != null) ? dateFormatter.format(date) : "";
            }

            @Override
            public LocalDate fromString(String string) {
                return (string != null && !string.isEmpty()) ? LocalDate.parse(string, dateFormatter) : null;
            }
        });
        dataV.setDayCellFactory(getDayCellFactory());
        dataV.setOnAction(event -> {
            dataSelezionata = dataV.getValue();
            compilaCampi();
        });

    }

    private void setNomePaziente(PazienteDTO paziente){
        nomePaziente.setText(paziente.getNome() + " " + paziente.getCognome());
    }
    private Callback<DatePicker, DateCell> getDayCellFactory() {
        return picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                if (empty || date == null) {
                    setDisable(true);
                    return;
                }
                LocalDate oggi = LocalDate.now();

                // Disabilita i giorni passati
                if (date.isBefore(oggi)) {
                    setDisable(true);
                    setStyle("-fx-background-color: #d3d3d3;"); // Opzionale: colore grigio per i giorni passati
                    return;
                }



                // Disabilita sabato e domenica
                if (date.getDayOfWeek().getValue() == 6 || date.getDayOfWeek().getValue() == 7) {
                    setDisable(true);
                    setStyle("-fx-background-color: #d3d3d3;"); // Opzionale: colore grigio per sabato e domenica
                } else if (assenze1.contains(date) && assenze2.contains(date) && assenze3.contains(date)) {
                    // Se tutti i medici sono assenti, disabilita il giorno e colora di rosso
                    setDisable(true);
                    setStyle("-fx-background-color: #ff0000;");
                } else if (assenze1.contains(date)) {
                    // Se solo il medico principale è assente, colora di giallo
                    setStyle("-fx-background-color: #ffc800;");
                }
            }
        };
    }

    private void compilaCampi() {
        campiVisibili();
        mediciDisponibili.clear();
        if (assenze1.contains(dataSelezionata)) {
            regimeV.setText("Medico Sostitutivo");
            if (assenze2.contains(dataSelezionata)) {// Se anche il secondo medico è assente, rimane solo il terzo sostituto
                String m = medicoSostituto2.getNome() + " " + medicoSostituto2.getCognome();
                mediciDisponibili.add(m);
                medicoV.setDisable(true);
            } else {// Se il secondo medico NON è assente, allora ci sono due medici disponibili
                String m1 = medicoSostituto1.getNome() + " " + medicoSostituto1.getCognome();
                String m2 = medicoSostituto2.getNome() + " " + medicoSostituto2.getCognome();
                mediciDisponibili.addAll(m1, m2);
                medicoV.setDisable(false);
            }
        } else {// Se il medico curante è disponibile
            regimeV.setText("Medico curante");
            String m = medicoCurante.getNome() + " " + medicoCurante.getCognome();
            mediciDisponibili.add(m);
            medicoV.setDisable(true);
        }

        medicoV.setItems(mediciDisponibili);
        medicoV.getSelectionModel().selectFirst(); // Seleziona il primo medico disponibile
        medicoV.setStyle("-fx-opacity: 1; -fx-text-fill: black");
        if (!medicoV.isDisabled()) {
            medicoV.valueProperty().addListener((observable, oldValue, newValue) -> {
                if (newValue != null) {
                    aggiornaOrariDisponibili(newValue);
                }
            });
        } else {
            aggiornaOrariDisponibili(medicoV.getSelectionModel().getSelectedItem());
        }
        tipoV.setText(pazienteFiglio == null ? "Adulti" : "Pediatrica");
    }

    private void campiVisibili(){
        labelMedico.setVisible(true);
        medicoV.setVisible(true);
        labelTipo.setVisible(true);
        tipoV.setVisible(true);
        labelOra.setVisible(true);
        oraV.setVisible(true);
        labelRegime.setVisible(true);
        regimeV.setVisible(true);
        bottonePrenotazione.setVisible(true);
    }

    private void aggiornaOrariDisponibili(String medicoSelezionato) {
        String codiceMedicoSelezionato = getCodiceMedicoSelezionato(medicoSelezionato);
        List<String[]> prenotazioniMedicoData = new ArrayList<>();
        List<String[]> prenotazioniPediatricheData = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        for (String[] visita : prenotazioni) {
            if (visita[3].equals(dataSelezionata.format(formatter))) {
                if (visita[0].equals(codiceMedicoSelezionato)) {
                    prenotazioniMedicoData.add(visita);
                }
                if (visita[5].equals("Pediatrica")) { // Supponiamo che il tipo di visita sia alla posizione 5
                    prenotazioniPediatricheData.add(visita);
                }
            }
        }

        ObservableList<String> orariDisponibili = getOrariDisponibili(prenotazioniMedicoData);

        if (dataSelezionata.isEqual(LocalDate.now())) {
            LocalTime oraAttuale = LocalTime.now();
            orariDisponibili.removeIf(ora -> LocalTime.parse(ora, DateTimeFormatter.ofPattern("HH:mm")).isBefore(oraAttuale));
        }
        List<String> orariOccupatiPerAmbulatori = new ArrayList<>();
        for (String orario : orariDisponibili) {
            int ambulatoriLiberi = 3;
            for (String[] prenotazione : prenotazioni) {
                if (prenotazione[3].equals(dataSelezionata.format(formatter)) &&
                        prenotazione[4].equals(orario)) {
                    ambulatoriLiberi--;
                }
            }
            if (ambulatoriLiberi <= 0) {
                orariOccupatiPerAmbulatori.add(orario);
            }
        }
        orariDisponibili.removeAll(orariOccupatiPerAmbulatori);
        List<String> orariOccupatiPediatria = new ArrayList<>();
        for (String[] visitaPediatrica : prenotazioniPediatricheData) {
            orariOccupatiPediatria.add(visitaPediatrica[4]);
        }
        orariDisponibili.removeAll(orariOccupatiPediatria);
        oraV.setItems(orariDisponibili);
    }


    private String getCodiceMedicoSelezionato(String medicoSelezionato) {
        String codiceMedicoSelezionato;
        if (medicoCurante != null && medicoSelezionato.equals(medicoCurante.getNome() + " " + medicoCurante.getCognome())) {
            codiceMedicoSelezionato = medicoCurante.getCodiceFiscale();
        } else if (medicoSostituto1 != null && medicoSelezionato.equals(medicoSostituto1.getNome() + " " + medicoSostituto1.getCognome())) {
            codiceMedicoSelezionato = medicoSostituto1.getCodiceFiscale();
        } else {
            codiceMedicoSelezionato = medicoSostituto2.getCodiceFiscale();
        }
        return codiceMedicoSelezionato;
    }

    private static ObservableList<String> getOrariDisponibili(List<String[]> prenotazioniMedicoData) {
        ObservableList<String> orariDisponibili = FXCollections.observableArrayList();
        for (int ora = 8; ora < 12; ora++) {
            orariDisponibili.add(String.format("%02d:00", ora));
            orariDisponibili.add(String.format("%02d:30", ora));
        }
        for (int ora = 14; ora < 18; ora++) {
            orariDisponibili.add(String.format("%02d:00", ora));
            orariDisponibili.add(String.format("%02d:30", ora));
        }

        // Rimuove gli orari occupati dai medici
        for (String[] prenotazione : prenotazioniMedicoData) {
            orariDisponibili.remove(prenotazione[4]); // Il campo oraV è l'indice 4
        }
        return orariDisponibili;
    }


    @FXML
    public void confermaV() throws IOException {
        if (oraV.getValue() != null) {
            ModelPrenotazioni visite = ModelPrenotazioni.getInstance();
            String ambulatorioV = null;
            String pz;
            String med;
            List<Object> dati = new ArrayList<>();
            if (pazienteFiglio != null) {
                pz = pazienteFiglio.getCodiceSanitario();
                dati.add(paziente);
                dati.add(pazienteFiglio);
            } else {
                pz = paziente.getCodiceSanitario();
                ambulatorioV = assegnaAmbulatorio();
            }

            if (medicoV.getValue().equals(medicoCurante.getNome() + " " + medicoCurante.getCognome()))
                med = medicoCurante.getCodiceFiscale();
            else if (medicoV.getValue().equals(medicoSostituto1.getNome() + " " + medicoSostituto1.getCognome()))
                med = medicoSostituto1.getCodiceFiscale();
            else
                med = medicoSostituto2.getCodiceFiscale();

            visite.aggiungiVisita(med, pz, tipoV.getText(), dataSelezionata.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")), oraV.getValue(), regimeV.getText(), ambulatorioV);

            HelloApplication pagina = new HelloApplication();
            if (pazienteFiglio != null)
                pagina.changeSceneWithData("VisualizzaPrenotazioni.fxml", dati);
            else
                pagina.changeSceneWithData("VisualizzaPrenotazioni.fxml", paziente);
        }
    }

    private String assegnaAmbulatorio() {
        for (String x : ambulatori) {
            boolean occupato = false;
            for (String[] y : prenotazioni) {
                String dataPrenotata = y[3];
                String oraPrenotata = y[4];
                String ambulatorioPrenotato = y[6];
                if (dataPrenotata.equals(dataSelezionata.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))) && ambulatorioPrenotato.equals(x) && oraPrenotata.equals(oraV.getValue())) {
                    occupato = true;
                    break;
                }
            }
            if (!occupato) {
                return x;
            }
        }
        return null;
    }


    @FXML
    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        if (pazienteFiglio != null) {
            List<Object> dati = new ArrayList<>();
            dati.add(paziente);
            dati.add(pazienteFiglio);
            pagina.changeSceneWithData("ProfiloFiglio.fxml", dati);
        }
        else
            pagina.changeSceneWithData("ProfiloUser.fxml", paziente);
    }
}
