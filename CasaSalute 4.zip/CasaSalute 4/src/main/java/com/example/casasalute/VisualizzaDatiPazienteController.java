package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class VisualizzaDatiPazienteController implements Initializable {

    @FXML private TableView<PazienteDTO> tabella;
    @FXML private TableColumn<PazienteDTO, String> cs;
    @FXML private TableColumn<PazienteDTO, String> nome;
    @FXML private TableColumn<PazienteDTO, String> cognome;
    @FXML private TableColumn<PazienteDTO, String> data;
    @FXML private TableColumn<PazienteDTO, String> luogo;
    @FXML private TableColumn<PazienteDTO, String> email;
    @FXML private TableColumn<PazienteDTO, String> password;
    @FXML private TableColumn<PazienteDTO, String> emailTut;
    @FXML private TableColumn<PazienteDTO, String> medicoCurante;
    @FXML private TableColumn<PazienteDTO, String> csTut;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        cs.setCellValueFactory(new PropertyValueFactory<>("codiceSanitario"));
        nome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        cognome.setCellValueFactory(new PropertyValueFactory<>("cognome"));
        data.setCellValueFactory(new PropertyValueFactory<>("data"));
        luogo.setCellValueFactory(new PropertyValueFactory<>("luogo"));
        email.setCellValueFactory(new PropertyValueFactory<>("email"));
        password.setCellValueFactory(new PropertyValueFactory<>("password"));
        emailTut.setCellValueFactory(new PropertyValueFactory<>("emailTutore"));
        medicoCurante.setCellValueFactory(new PropertyValueFactory<>("medico"));
        csTut.setCellValueFactory(new PropertyValueFactory<>("CSTutore"));

        ObservableList<PazienteDTO> pazientiObservable = FXCollections.observableList(ModelPazienti.getInstance().getAllPazienti());
        tabella.setItems(pazientiObservable);

        tabella.setRowFactory(tv -> {
            TableRow<PazienteDTO> row = new TableRow<>() {
                @Override
                protected void updateItem(PazienteDTO paziente, boolean empty) {
                    super.updateItem(paziente, empty);
                    if (empty || paziente == null) {
                        setStyle(""); // Reset dello stile
                    } else if ("null".equals(paziente.getMedico())) {
                        setStyle("-fx-background-color: #FFCCCC;"); // Sfondo rosso chiaro
                    } else {
                        setStyle("");
                    }
                }
            };
            row.setOnMouseClicked(event -> {
                if (!row.isEmpty() && event.getClickCount() == 1) {
                    PazienteDTO selectedPaziente = row.getItem();
                    try {
                        handleRowClick(selectedPaziente);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            return row;
        });
    }

    private void handleRowClick(PazienteDTO paziente) throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("ModificaPaziente.fxml", paziente);
    }

    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("Segreteria.fxml");
    }
}
