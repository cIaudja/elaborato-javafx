package com.example.casasalute;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CreaPrestazioneController implements DataReceiver {

    @FXML public Label nomeInfermiere;
    @FXML private Label pazienteP;
    @FXML private Label tipoP;
    @FXML private Label dataP;
    @FXML private Label oraP;
    @FXML private TextArea esitoP;
    @FXML private TextField noteP;
    @FXML private Label errore;
    private final List<PazienteDTO> pazienti = ModelPazienti.getInstance().getAllPazienti();
    private InfermiereDTO infermiere;
    private PazienteDTO paziente;

    @Override
    public void setData(Object data) {
        if (data instanceof ArrayList<?> datiPassati){
            infermiere = (InfermiereDTO) datiPassati.getFirst();
            nomeInfermiere.setText(infermiere.getNome() + " " + infermiere.getCognome());
            for (PazienteDTO x: pazienti)
                if (x.getCodiceSanitario().equals(datiPassati.get(2))) {
                    pazienteP.setText(x.getNome() + " " + x.getCognome());
                    paziente = x;
                }
            tipoP.setText((String) datiPassati.get(1));
            dataP.setText((String) datiPassati.get(3));
            oraP.setText((String) datiPassati.get(4));
        }
    }

    @FXML
    public void salvaP() {
        if (controllo()) {
            try {
                File pdfFile = creaPDF();
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(pdfFile);
                }
                String nomeFile = tipoP.getText() + "_" + dataP.getText() + ".pdf" ;
                if (paziente == null)
                    for (PazienteDTO x : pazienti)
                        if (pazienteP.getText().equals(x.getNome() + " " + x.getCognome()))
                            paziente = x;

                RefertoDTO nuovaPrestazione = new RefertoDTO(nomeFile, dataP.getText(), infermiere.getCodiceFiscale(), paziente.getCodiceSanitario(), esitoP.getText());
                ModelReferti.getInstance().aggiungiReferto(nuovaPrestazione);
                ModelPrenotazioni.rimuoviPrestazione(tipoP.getText(), paziente.getCodiceSanitario(), dataP.getText(), oraP.getText());

                MailDTO nuovaMail = getMailDTO(nuovaPrestazione);
                ModelMail.getInstance().aggiungiMail(nuovaMail);

                HelloApplication pagina = new HelloApplication();
                pagina.changeSceneWithData("StoricoReferti.fxml", infermiere);
            } catch (Exception e) {
                System.out.println("Errore, Si è verificato un errore durante la generazione del PDF: " + e);
            }
        }
    }

        private MailDTO getMailDTO(RefertoDTO nuovaPrestazione) {
        String tipoPrestazione;
        if (tipoP.getText().equals("Prelievo"))
            tipoPrestazione = "del prelievo";
        else
            tipoPrestazione = "della medicazione";
        String corpo;
        if (!paziente.getCSTutore().equals("null"))
            corpo = "La informiamo che per il paziente nato il " + paziente.getData() + " del suo nucleo familiare, è disponibile il referto " + nuovaPrestazione.getCodiceReferto() + " " + tipoPrestazione + " accedendo al portale";
        else
            corpo = "La informiamo che per il paziente nato il " + paziente.getData() + " è disponibile il referto " + nuovaPrestazione.getCodiceReferto() + " " + tipoPrestazione + " accedendo al portale";
        String tutore = "null";
        if (!paziente.getEmailTutore().equals("null"))
            tutore = paziente.getEmailTutore();
        return new MailDTO(nuovaPrestazione.getCodiceReferto(), paziente.getEmail(), tutore, corpo);
    }
        private boolean controllo() {
        if (pazienteP.getText().isEmpty() || tipoP.getText().isEmpty() || dataP.getText().isEmpty() || oraP.getText().isEmpty() || esitoP.getText().isEmpty()) {
            errore.setText("Tutti i campi devono essere compilati (eccetto note aggiuntive)");
            return false;
        }
        return true;
    }

    private File creaPDF() throws IOException {
        PDDocument document = new PDDocument();
        PDPage page = new PDPage();
        document.addPage(page);

        try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 14);

            // Inserimento logo
            try {
                PDImageXObject logo = PDImageXObject.createFromFile("src/main/resources/img/logo_colorato.png", document);
                contentStream.drawImage(logo, 50, 720, 50, 50); // Posizione e dimensioni
            } catch (IOException e) {
                System.err.println("Errore nel caricamento del logo: " + e.getMessage());
            }

            // Titolo del documento
            contentStream.beginText();
            contentStream.newLineAtOffset(200, 750);
            contentStream.showText("Casa Salute - Report Visita");
            contentStream.endText();

            // Sezione Dati Paziente
            contentStream.beginText();
            contentStream.setFont(PDType1Font.HELVETICA, 12);
            contentStream.newLineAtOffset(50, 680);
            contentStream.showText("Nome e Cognome: " + pazienteP.getText());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Codice Sanitario: " + paziente.getCodiceSanitario());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Data di Nascita: " + paziente.getData());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Luogo di Nascita: " + paziente.getLuogo());
            contentStream.newLineAtOffset(0, -20);

            // Email del tutore se il paziente è minorenne
            if (!paziente.getCSTutore().equals("null")) {
                contentStream.showText("Email Tutore: " + paziente.getEmailTutore());
                contentStream.newLineAtOffset(0, -30);
            } else {
                if (!paziente.getEmailTutore().equals("null")) {
                    contentStream.showText("Email Paziente: " + paziente.getEmail());
                    contentStream.newLineAtOffset(0, -30);
                    contentStream.showText("Email Tutore: " + paziente.getEmailTutore());
                    contentStream.newLineAtOffset(0, -30);
                }
                else {
                    contentStream.showText("Email Paziente: " + paziente.getEmail());
                    contentStream.newLineAtOffset(0, -30);
                }
            }
            contentStream.endText();

            // Linea divisoria prima della sezione sintomi e diagnosi
            contentStream.moveTo(50, 540);
            contentStream.lineTo(550, 540);
            contentStream.stroke();

            // Sezione Dettagli Visita
            contentStream.beginText();
            contentStream.newLineAtOffset(50, 520);
            contentStream.showText("Tipo Prestazione: " + tipoP.getText());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Data: " + dataP.getText());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Ora: " + oraP.getText());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Esito: " + esitoP.getText());
            contentStream.newLineAtOffset(0, -20);
            contentStream.showText("Note Aggiuntive: " + noteP.getText());
            contentStream.newLineAtOffset(0, -30); // Spazio prima della linea divisoria successiva
            contentStream.endText();

            // Sezione infermiere e sostituzione
            contentStream.beginText();
            contentStream.newLineAtOffset(50, 300);
            contentStream.showText("Infermiere: " + infermiere.getNome() + " " + infermiere.getCognome());
            contentStream.endText();
        }

        // Creazione del nome del file basato sul tipo di visita
        String nomeFile = tipoP.getText() + "_" + dataP.getText() + ".pdf";

        String path = "src/main/pdf/" + nomeFile;
        File outputFile = new File(path);
        document.save(outputFile);
        document.close();
        return outputFile;
    }

    @FXML
    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeSceneWithData("RefertiPrenotazioni.fxml", infermiere);
    }
}
