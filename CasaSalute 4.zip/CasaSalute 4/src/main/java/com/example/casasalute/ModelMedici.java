package com.example.casasalute;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ModelMedici {
    
    private static ModelMedici instance;
    private static final String FILE_PATH = "src/main/txt/medici.txt";
    private static final List<MedicoDTO> medici = new ArrayList<>();

    public static ModelMedici getInstance() {
        if (instance == null){
            instance = new ModelMedici();
        }
        return instance;
    }

    ModelMedici() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] dati = line.split("\t");
                if (dati.length == 8) {
                    MedicoDTO medico = new MedicoDTO(
                            dati[0], // CF
                            dati[1], // nome
                            dati[2], // cognome
                            dati[3], // email
                            dati[4], // password
                            dati[5], // specialita
                            dati[6], //medico sostituito 1
                            dati[7] //medico sostituito 2
                    );
                    medici.add(medico);
                }
            }
        } catch (IOException e) {
            System.err.println("Nessun file medici trovato: " + e);
        }
    }

    public static void aggiungiMedico(MedicoDTO medico) {
       medici.add(medico);
       aggiornaFile();
    }

    public static void aggiornaFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (MedicoDTO medico : medici) {
                writer.write(medico.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Errore durante l'aggiornamento del file: " + e.getMessage());
        }
    }

    public List<MedicoDTO> getAllMedici() {
        return medici;
    }

}
