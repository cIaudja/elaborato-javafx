package com.example.casasalute;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ModelMail {

    private static ModelMail instance;
    private static final String FILE_PATH = "src/main/txt/mails.txt";
    private static final List<MailDTO> mails = new ArrayList<>();

    public static ModelMail getInstance() {
        if (instance == null) {
            instance = new ModelMail();
        }
        return instance;
    }

    ModelMail() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] dati = line.split("\t");
                if (dati.length == 5) {
                    MailDTO mail = new MailDTO(
                            dati[0], // oggetto
                            //mittente
                            dati[2], // destinatario
                            dati[3],  // email tutore
                            dati[4]  // corpo del messaggio
                    );
                    mails.add(mail);
                }
            }
        } catch (IOException e) {
            System.err.println("Nessun file mail trovato: " + e);
        }
    }

    public void aggiungiMail(MailDTO mail) {
        mails.add(mail);
        aggiornaFile();
    }

    public static void aggiornaFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (MailDTO x : mails) {
                writer.write(x.getOggetto() + "\t" +
                        x.getMittente() + "\t" +
                        x.getDestinatario() + "\t" +
                        x.getEmailTutore() + "\t" +
                        x.getCorpo());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Errore durante l'aggiornamento del file: " + e.getMessage());
        }
    }

    public List<MailDTO> getAllMail(){
        return mails;
    }
}
