package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;

public class VisualizzaDatiPazienteResocontoController implements Initializable, DataReceiver {

    @FXML private TableView<PazienteDTO> tabella;
    @FXML private TableColumn<PazienteDTO, String> cs;
    @FXML private TableColumn<PazienteDTO, String> nome;
    @FXML private TableColumn<PazienteDTO, String> cognome;
    @FXML private TableColumn<PazienteDTO, String> data;
    @FXML private TableColumn<PazienteDTO, String> luogo;
    @FXML private TableColumn<PazienteDTO, String> email;
    @FXML private TableColumn<PazienteDTO, String> password;
    @FXML private TableColumn<PazienteDTO, String> emailTut;
    @FXML private TableColumn<PazienteDTO, String> medicoCurante;
    @FXML private Label accesso;
    @FXML private Label nomeInfermiere;
    private InfermiereDTO infermiere;

    @Override
    public void setData(Object data){
        if (data instanceof InfermiereDTO) {
            infermiere = (InfermiereDTO) data;
            accesso.setText("INFERMIERE");
            nomeInfermiere.setText(infermiere.getNome() + " " + infermiere.getCognome());
        } else
            accesso.setText("SEGRETERIA");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        cs.setCellValueFactory(new PropertyValueFactory<>("codiceSanitario"));
        nome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        cognome.setCellValueFactory(new PropertyValueFactory<>("cognome"));
        data.setCellValueFactory(new PropertyValueFactory<>("data"));
        luogo.setCellValueFactory(new PropertyValueFactory<>("luogo"));
        email.setCellValueFactory(new PropertyValueFactory<>("email"));
        password.setCellValueFactory(new PropertyValueFactory<>("password"));
        emailTut.setCellValueFactory(new PropertyValueFactory<>("emailTutore"));
        medicoCurante.setCellValueFactory(new PropertyValueFactory<>("medico"));

        ObservableList<PazienteDTO> pazientiObservable = FXCollections.observableList(ModelPazienti.getInstance().getAllPazienti());
        tabella.setItems(pazientiObservable);

        tabella.setRowFactory(tv -> {
            TableRow<PazienteDTO> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (!row.isEmpty() && event.getClickCount() == 1) { // Click singolo
                    PazienteDTO selectedPaziente = row.getItem();
                    try {
                        resoconto(selectedPaziente);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            });
            return row;
        });

    }

    private void resoconto(PazienteDTO paziente) throws IOException {
        HelloApplication pagina = new HelloApplication();
        List<Object> dati = new ArrayList<>();
        dati.add(Objects.requireNonNullElse(infermiere, "s"));
        dati.add(paziente);
        pagina.changeSceneWithData("Resoconto.fxml", dati);

    }

    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();

        if (infermiere != null)
            pagina.changeSceneWithData("ProfiloInfermiere.fxml", infermiere);
        else
            pagina.changeScene("Segreteria.fxml");
    }
}




