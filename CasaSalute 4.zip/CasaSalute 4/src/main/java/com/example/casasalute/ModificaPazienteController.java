package com.example.casasalute;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.io.IOException;
import java.util.*;

public class ModificaPazienteController implements DataReceiver {

    @FXML private Label nomePaziente;
    @FXML private Label nomeText;
    @FXML private Label cognomeText;
    @FXML private Label dataText;
    @FXML private Label luogoText;
    @FXML private TextField emailText;
    @FXML private TextField passwordText;
    @FXML private TextField emailTutorText;
    @FXML private ChoiceBox<String> medicoCuranteText;
    @FXML private Label errore;
    private PazienteDTO paziente;
    private MedicoDTO medico;
    String tendinaMedico;
    String vecchioMedico;
    private final List<String> codiceMedici = new ArrayList<>();
    private final List<MedicoDTO> medici = ModelMedici.getInstance().getAllMedici();
    private final List<String[]> visite = ModelPrenotazioni.getInstance().getAllVisite();

    @Override
    public void setData(Object data) {
        if (data instanceof PazienteDTO) {
            paziente = (PazienteDTO) data;
            nomePaziente.setText(paziente.getNome() + " " + paziente.getCognome());
            datiPaziente(paziente);
            List<MedicoDTO> medici = ModelMedici.getInstance().getAllMedici();
            if (!medici.isEmpty()) {
                for (MedicoDTO x : medici)
                    codiceMedici.add(x.getNome() + " " + x.getCognome());

                medicoCuranteText.setItems(FXCollections.observableArrayList(codiceMedici));
                tendinaMedico =  medicoCuranteText.getValue();
            }
            medicoCuranteText.setOnAction(event -> confermaCambioMedico());
        }
    }

    private void confermaCambioMedico() {
        vecchioMedico = tendinaMedico;
        String nuovoMedico = medicoCuranteText.getValue();
        if (tendinaMedico.equals("null") || tendinaMedico.isEmpty()) {
            tendinaMedico = nuovoMedico;
            for (MedicoDTO x : medici) {
                if (nuovoMedico.equals(x.getNome() + " " + x.getCognome())) {
                    medico = x;
                    break;
                }
            }
            return;
        }
        if (medico != null && nuovoMedico.equals(medico.getNome() + " " + medico.getCognome())) {
            return;
        }
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Cambio medico curante");
        alert.setHeaderText("Stai per cambiare il medico curante.");
        alert.setContentText("Se cambi il medico curante verranno eliminate le prenotazioni delle visite mediche future. Verrà inoltre modificato il medico anche ai membri del nucleo familiare e verranno eliminate le prenotazioni delle loro visite mediche future.\nVuoi continuare?");

        ButtonType buttonOK = new ButtonType("OK");
        ButtonType buttonCancel = new ButtonType("Annulla");

        alert.getButtonTypes().setAll(buttonOK, buttonCancel);

        alert.showAndWait().ifPresent(response -> {
            if (response == buttonOK) {
                for (MedicoDTO x : medici) {
                    if (nuovoMedico.equals(x.getNome() + " " + x.getCognome())) {
                        medico = x;
                        break;
                    }
                }
            } else {
                if (medico != null) {
                    medicoCuranteText.setValue(medico.getNome() + " " + medico.getCognome());
                } else {
                    medicoCuranteText.setValue("");
                }
            }
        });
    }

    private void datiPaziente(PazienteDTO paziente){
        nomeText.setText(paziente.getNome());
        cognomeText.setText(paziente.getCognome());
        dataText.setText(paziente.getData());
        luogoText.setText(paziente.getLuogo());

        emailText.setText(paziente.getEmail());
        passwordText.setText(paziente.getPassword());
        emailTutorText.setText(paziente.getEmailTutore());
        for (MedicoDTO x : medici) {
            if (x.getCodiceFiscale().equals(paziente.getMedico())) {
                medico = x;
                medicoCuranteText.setValue(medico.getNome() + " " + medico.getCognome());
                break;
            } else
                medicoCuranteText.setValue("");
        }
    }



    @FXML
    private void modificaPaziente() throws IOException {
        String codice = paziente.getCodiceSanitario();
        if (controlliValidazione()) {
            List<PazienteDTO> pazienti = ModelPazienti.getInstance().getAllPazienti();
            PazienteDTO pazienteTrovato = pazienti.stream()
                    .filter(p -> p.getCodiceSanitario().equalsIgnoreCase(codice))
                    .findFirst()
                    .orElse(null);
            if (pazienteTrovato != null) {
                pazienteTrovato.setCodiceSanitario(pazienteTrovato.getCodiceSanitario());
                pazienteTrovato.setNome(nomeText.getText());
                pazienteTrovato.setCognome(cognomeText.getText());
                pazienteTrovato.setData(dataText.getText());
                pazienteTrovato.setLuogo(luogoText.getText());
                pazienteTrovato.setEmail(emailText.getText());
                pazienteTrovato.setPassword(passwordText.getText());
                pazienteTrovato.setEmailTutore(emailTutorText.getText());
                for (MedicoDTO x : medici)
                    if (medicoCuranteText.getValue().equals(x.getNome() + " " + x.getCognome())) {
                        medico = x;
                        break;
                    }
                pazienteTrovato.setMedico(medico.getCodiceFiscale());
                if (!vecchioMedico.equals(medico.getNome() + " " + medico.getCognome()))
                    for (String[] x : visite) {
                        if (x[1].equals(paziente.getCodiceSanitario()))
                            ModelPrenotazioni.rimuoviVisita(x[0], x[1], x[3], x[4]);
                    }

                for (PazienteDTO x : pazienti) {
                    if (x.getCSTutore() != null && x.getCSTutore().equals(codice)) {
                        x.setMedico(pazienteTrovato.getMedico());
                        if (!vecchioMedico.equals(medico.getNome() + " " + medico.getCognome()))
                            for (String[] y: visite) {
                                if (y[1].equals(x.getCodiceSanitario()))
                                    ModelPrenotazioni.rimuoviVisita(y[0], y[1], y[3], y[4]);
                            }
                    }
                    if (x.getEmailTutore() != null && x.getEmailTutore().equals(paziente.getEmail()))
                        x.setEmailTutore(pazienteTrovato.getEmail());
                }
                ModelPazienti.getInstance().aggiornaFile();
                HelloApplication pagina = new HelloApplication();
                pagina.changeScene("VisualizzaDatiPaziente.fxml");
            } else
                System.out.print("Errore: Paziente non trovato.");
        }
    }

    private boolean controlliValidazione() {
        if (emailText.getText().isEmpty() || passwordText.getText().isEmpty() || medicoCuranteText.getValue().isEmpty()) {
            errore.setText("Tutti i campi devono essere compilati!");
            return false;
        }

        if (!dataText.getText().matches("\\d{2}/\\d{2}/\\d{4}")) {
            errore.setText("Il formato della data deve essere gg/mm/aaaa!");
            return false;
        }

        if (!emailText.getText().matches("^[\\w.-]+@[a-zA-Z\\d.-]+\\.[a-zA-Z]{2,}$")) {
            errore.setText("L'email non è valida!");
            return false;
        }

        int eta = calcolaEta(dataText.getText());
        if (eta < 14 || eta > 110) {
            errore.setText("Età non valida!");
            return false;
        }
        if (eta < 18 && !emailTutorText.getText().isEmpty() && !emailTutorText.getText().matches("^[\\w.-]+@[a-zA-Z\\d.-]+\\.[a-zA-Z]{2,}$")) {
            errore.setText("L'email del tutore non è valida.");
            return false;
        }

        return true;
    }


    private int calcolaEta(String dataNascita) {
        String[] parts = dataNascita.split("/");
        int giorno = Integer.parseInt(parts[0]);
        int mese = Integer.parseInt(parts[1]);
        int anno = Integer.parseInt(parts[2]);
        Calendar cal = Calendar.getInstance();
        int annoCorrente = cal.get(Calendar.YEAR);
        int meseCorrente = cal.get(Calendar.MONTH) + 1;
        int giornoCorrente = cal.get(Calendar.DAY_OF_MONTH);
        int eta = annoCorrente - anno;
        if (meseCorrente < mese || (meseCorrente == mese && giornoCorrente < giorno)) {
            eta--;
        }
        return eta;
    }

    @FXML
    public void back() throws IOException {
        HelloApplication pagina = new HelloApplication();
        pagina.changeScene("VisualizzaDatiPaziente.fxml");
    }

}
